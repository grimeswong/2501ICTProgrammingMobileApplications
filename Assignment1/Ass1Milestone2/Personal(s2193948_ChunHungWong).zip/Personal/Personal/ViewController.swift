//
//  ViewController.swift
//  Personal
//
//  Created by Grimes Wong s2193948 on 9/03/2016.
//  Copyright © 2016 Grimes Wong. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var firstNameTextField: UITextField!
    @IBOutlet weak var middleNameTextField: UITextField!
    @IBOutlet weak var lastNameTextField: UITextField!
    @IBOutlet weak var ageTextField: UITextField!
    @IBOutlet weak var showFullNameLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func showFullNameButton() {
        
        //condtion bottom line: first name & lastname & age between 0 to 150
        if firstNameTextField.text != "" && lastNameTextField.text != "" && ageTextField != nil && Int(ageTextField.text!) >= 0 && Int(ageTextField.text!) <= 150 {
            
            //tester    showFullNameLabel.text = "Do something here yeah"
            
            let ageInt = Int(ageTextField.text!) // Unwrappeed age to Int (confirmed proper value to Int)
            let currentPerson = Person(firstName: firstNameTextField.text!, lastName: lastNameTextField.text!, age: ageInt!, middleName: middleNameTextField.text!)
            
            //Show the full name and age if the user enter the correct details
            showFullNameLabel.text = currentPerson.fullName() + " aged \(currentPerson.age)"
            
        }else{
            showFullNameLabel.text = "Please enter correct details"
        }
        
        
    }

}

