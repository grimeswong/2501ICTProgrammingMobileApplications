//
//  File.swift
//  Personal
//
//  Created by Grimes Wong on 9/03/2016.
//  Copyright © 2016 Grimes Wong. All rights reserved.
//


class Person{
    
    var firstName:String
    var lastName: String
    var middleName: String?
    var age: Int
    
    init(firstName:String, lastName:String, age:Int, middleName:String?=nil) {
        self.firstName = firstName
        self.lastName = lastName
        self.age = age
        self.middleName = middleName
    }
    
    /*This function(method) will return the full name 
    Return type: String
    */
    func fullName() ->String { //return type:String
        if middleName == nil {
            let tempFullDetails = "\(firstName) \(lastName)"
            return tempFullDetails
            
        }else{
            let tempFullDetails = "\(firstName) \(middleName!) \(lastName)"
            return tempFullDetails
        }
    }
    
}