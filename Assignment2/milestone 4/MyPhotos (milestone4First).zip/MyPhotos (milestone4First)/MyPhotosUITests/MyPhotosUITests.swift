//
//  MyPhotosUITests.swift
//  MyPhotosUITests
//
//  Created by s2193948 on 8/04/2016.
//  Copyright © 2016 s2193948. All rights reserved.
//

import XCTest

class MyPhotosUITests: XCTestCase {
        
    override func setUp() {
        super.setUp()
        
        // Put setup code here. This method is called before the invocation of each test method in the class.
        
        // In UI tests it is usually best to stop immediately when a failure occurs.
        continueAfterFailure = false
        // UI tests must launch the application that they test. Doing this in setup will make sure it happens for each test method.
        XCUIApplication().launch()

        // In UI tests it’s important to set the initial state - such as interface orientation - required for your tests before they run. The setUp method is a good place to do this.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testExample() {
        // Use recording to get started writing UI tests.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func wait(delay: NSTimeInterval = 2){
        let runLoop = NSRunLoop.mainRunLoop()
        let someTimeInTheFuture = NSDate(timeIntervalSinceNow: delay)
        runLoop.runUntilDate(someTimeInTheFuture)
    }
    
    /**
        Testing the add button, confirm the object is added after the user enter title, tags, and URL
        (Problem: if user has something in the copy clipboard that this test may not working)
    */
    func testAddingPhoto(){    //worked iPhone4s if disable connect hardward keyborad
        
        let app = XCUIApplication()
        wait(5)
        app.navigationBars["Photo Collection"].buttons["Add"].tap()
        let titleTextField = app.textFields["Title"]
        titleTextField.tap()
        app.textFields["Title"]
        app.typeText("Griffith")
        app.typeText("\r")
        //app.typeText("\u{53}") //esc key
        wait(2)
        let tagsTextField = app.textFields["Tags"]
        tagsTextField.tap()
        app.textFields["Tags"]
        app.typeText("Brisbane, University")
        app.typeText("\r")
        wait(2)
        let urlTextField = app.textFields["URL"]
        urlTextField.tap()
        app.textFields["URL"]
        app.typeText("http://acsfoundation.com.au/bdi/assets/img/logos/Griffith3.png")
        app.typeText("\r")
        wait(2)
        //pan gesture back
        app.swipeLeft()
       // app.staticTexts["Image  Preview:"].tap()
        //tap the back button 
//        app.navigationBars["Photo"].childrenMatchingType(.Button).matchingIdentifier("Back").elementBoundByIndex(0).tap()
        wait(2)
        }
    
    /**
        Testing the photo details are correct that after the user changed the title, tags and URL.
    */
    func testEditingPhoto(){ //worked iPhone4s if disable connect hardward keyborad
        
        let app = XCUIApplication()
        wait(5)
        while app.cells.count <= 0{ // if photolist is 0, use the adding test which can add a photo object to the app
            testAddingPhoto()
        }
        let testingIndex = app.cells.count - 1
        let image = app.collectionViews.childrenMatchingType(.Cell).elementBoundByIndex(testingIndex).otherElements.childrenMatchingType(.Image).element
        image.tap()
        wait(2)
        app.swipeLeft()
        app.swipeRight()
        app.swipeLeft()
        app.swipeLeft()
        app.swipeLeft()
        app.tap()
        let titleTextField = app.textFields["Title"]
        titleTextField.tap()
        app.textFields["Title"]
        app.typeText(" University")
        app.typeText("\r")
        wait(2)
        let tagsTextField = app.textFields["Tags"]
        tagsTextField.tap()
        app.textFields["Tags"]
        app.typeText(", Wonderful")
        app.typeText("\r")
        wait(2)
        let urlTextField = app.textFields["URL"]
        urlTextField.tap()
        app.textFields["URL"]
        while (app.textFields["URL"].value as! String).characters.count > 0 {
            app.typeText("\u{8}")   //delete button
        }
        app.typeText("http://acsfoundation.com.au/bdi/assets/img/logos/Griffith3.png")
        app.typeText("\r")
        wait(2)
        app.swipeRight()    //back to Full view mode
        app.tap()       // enter back to detail view of the edited image
        
        /*let backButton = app.navigationBars["Photo"].childrenMatchingType(.Button).matchingIdentifier("Back").elementBoundByIndex(0)
        backButton.tap()
        wait(2)
        image.tap()
        wait(2)
        backButton.tap()
        wait(2)
         */
    }
    
    /** 
        Testing the button for deleting a photo object, also test the cancel to delete a photo object button
     */
    func testDeletingPhoto() {
        let app = XCUIApplication()
        wait(5)
        while app.cells.count <= 1{ // if photolist is less than two, use the adding test which can add a photo object to the app until reach two
            testAddingPhoto()          // at least two photo objects in the list
        }
        let testingIndex = app.cells.count - 1
        wait(5)
        let collectionViewsQuery = app.collectionViews
    collectionViewsQuery.childrenMatchingType(.Cell).elementBoundByIndex(testingIndex).otherElements.childrenMatchingType(.Image).element.tap()
        wait(2)
        app.swipeLeft()
        app.swipeLeft()
        app.swipeLeft()
        app.swipeRight()
        app.swipeRight()
        app.swipeRight()
        app.tap()
        let deleteButton = app.navigationBars["Photo"].buttons["Delete"]
        while !deleteButton.exists {
            wait(2)
            print("wait 2 seoconds... on rubbish bin button")
        }
        deleteButton.tap()
        let confirmDeleteSheet = app.sheets["Confirm Delete"]
        confirmDeleteSheet.buttons["Cancel"].tap()
        deleteButton.tap()
        wait(2)
        let deleteButton2 = confirmDeleteSheet.collectionViews.buttons["Delete"]
        deleteButton2.tap()
        wait(5)
    }
    
    
    /**
        Test the swipe left and right function in the Full view mode
     */
    func testSwipeLeftAndRight() {
        XCUIDevice.sharedDevice().orientation = .Portrait
        
        let app = XCUIApplication()
        wait(5)
        while app.cells.count <= 0{ // if photolist is 0, use the adding test which can add a photo object to the app
            testAddingPhoto()
        }
        let testingIndex = app.cells.count - 1
        let image = app.collectionViews.childrenMatchingType(.Cell).elementBoundByIndex(testingIndex).otherElements.childrenMatchingType(.Image).element
        image.tap()
        wait(5)
        app.swipeLeft()
        app.swipeRight()
        app.swipeRight()
        app.swipeRight()
        app.swipeRight()
        app.tap()
        app.swipeLeft()
        app.swipeRight()
        app.swipeLeft()
        app.swipeLeft()
        app.swipeLeft()
        app.swipeLeft()
    }
    
} // end of test class
