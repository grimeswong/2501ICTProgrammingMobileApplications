//
//  ViewController.swift
//  MyPhotos
//
//  Created by s2193948 on 8/04/2016.
//  Copyright © 2016 s2193948. All rights reserved.
//  Purpose: This class is the collection view that list out all the images, and can modify exisiting photos' details or adding a new image

import UIKit

class MasterViewController: UICollectionViewController, DetailViewControllerDelegate, FullViewControllerDelegate {
    
    // MARK: Properties
    
    var masterEntries = PhotoList().entries     //a list to store the images
    var currentImageIndex : Int? = nil          //save the photo object index which using by masterview controller
    var currentPhoto: Photo? = nil              //the current Photo object
    var imageCacheDict : [String: UIImage] = [:]       //Dictionary to store temp images, [:] = empty Dictionary
    var currentIndexPath = NSIndexPath()
    
    // MARK: Main UI Functions
    /**
        load the properlist and copy the photo data to the Photo array if property is exsiting, otherwise, a new property list will be created with some sample data
     */
    override func viewDidLoad() {
        super.viewDidLoad()
        //  load exisiting property list
        let array = NSMutableArray(contentsOfFile: setupPropertylist())
        if array != nil{
//            print("array = \(array)")
            print("array.count = \(array!.count)")
            print("plist is exsiting")
            print("plist path is = \(setupPropertylist())")
            //  load plist
            for element in array! {
                let changeToNormalString = changeType(element)
                masterEntries.append(Photo(title: changeToNormalString.0, tags: changeToNormalString.1, uRL: changeToNormalString.2))
                
                //save images in the imageCache
                if let saveURL = NSURL(string: changeToNormalString.2), let saveData = NSData(contentsOfURL: saveURL){
                    if let saveImage = UIImage(data: saveData){
                        imageCachingSave(changeToNormalString.2, imageToStore: saveImage)
                    }
                }
            }
    
        } else {
//            print("plist is nil")
            //  create plist? set three samples into property list
            let newPhoto = Photo(title: "Griffith University", tags: ["Nathan", "Logan", "South Bank", "Gold Coast"], uRL: "http://www.acsfoundation.com.au/bdi/assets/img/logos/Griffith3.png")
            let newPhoto2 = Photo(title: "University Of Queensland", tags: ["St Lucia", "Gatton", "Herston"], uRL: "http://www.uq.edu.au/international/images/banners/UQlogoC-colour-M.jpg")
            let newPhoto3 = Photo(title: "Queensland University Technology", tags: ["Gardens Point", "Kelvin Grove","Caboolture"], uRL: "http://acems.org.au/acems_wp/wp-content/uploads/2015/09/QUT_Logo_2Lines_CMYK.jpg")
            let newPhoto4 = Photo(title: "Central Queensland University", tags: ["Brisbane"], uRL: "https://www.cqu.edu.au/__data/assets/image/0003/106977/site-logo.png")
            let newPhoto5 = Photo(title: "Bond University", tags: ["Robina"], uRL: "http://www.alumni.bond.edu.au/s/865/images/editor/resources/bond_logo_without_wording.bmp")
            let pl = propertyListRepresentation(newPhoto)
            let pl2 = propertyListRepresentation(newPhoto2)
            let pl3 = propertyListRepresentation(newPhoto3)
            let pl4 = propertyListRepresentation(newPhoto4)
            let pl5 = propertyListRepresentation(newPhoto5)
            let arrayNew : NSMutableArray = []   //create an array
            arrayNew.addObject(pl)
            arrayNew.addObject(pl2)
            arrayNew.addObject(pl3)
            arrayNew.addObject(pl4)
            arrayNew.addObject(pl5)
            arrayNew.writeToFile(setupPropertylist(), atomically: true)      //write data to propertyList
            //  load plist out to
            for element in arrayNew {
                let changeToNormalString = changeType(element)
                masterEntries.append(Photo(title: changeToNormalString.0, tags: changeToNormalString.1, uRL: changeToNormalString.2))
                //save images in the imageCache
                if let saveURL = NSURL(string: changeToNormalString.2), let saveData = NSData(contentsOfURL: saveURL){
                    if let saveImage = UIImage(data: saveData){
                        imageCachingSave(changeToNormalString.2, imageToStore: saveImage)
                    }
                }

            }
        }
//        For reference only as below (Author use only)
//        let linkURL = NSURL(string: masterEntries[0].uRL!)
//        let data = NSData(contentsOfURL: linkURL!)
//        let image = UIImage(data: data!)
    
    /*  for foto in photolist {
        loadPhotoInBackground(photo: foto) // load the function which download an image in background (Multithread)
        }
    */
    
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        self.collectionView!.reloadData()       //reload images
        /* Photo list counters */
        let currentArray = NSMutableArray(contentsOfFile: setupPropertylist())
        print("masterEntries.count = \(masterEntries.count) in viewWillAppear in MasterView")
        print("CurrentArray.count in plist = \(currentArray!.count) in viewWillAppear in MasterView")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: Prepare For Segue
    /**
        Show selected image by segue or adding a new photo details
    */
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "ShowImage" {
            let fvc = segue.destinationViewController as! FullViewController
            fvc.fullViewDelegate = self //very important
            let indexPaths = self.collectionView!.indexPathsForSelectedItems()  //mutli selected
            let indexPath = indexPaths![0] as NSIndexPath                       //single select
            
            print("index Path = \(indexPath.row)")  //tester//
            currentIndexPath = indexPath    //save the current index path to global var
            
            print("currentIndexPath = \(currentIndexPath)")
            let tempLink = masterEntries[indexPath.row].uRL
            if tempLink != "" {                                 //Double confirm the url whether is an empty string
//                print("tempLink in Segue is  = \(tempLink)")
                let link = NSURL(string: tempLink)
//                print("link in Segue is = \(link)")
                if let data = NSData(contentsOfURL: link!) {
//                    print("data in Segue is = \(data)")
                    if let image = UIImage(data: data) {
                        print("image in Segue is = \(image)")
                        fvc.fvcText = "indexPath is \(indexPath.row)"
                        fvc.fvcImage = image
                    } else {
//                        fvc.fvcFullView.image = UIImage(named: "noImageAvailable")
                        fvc.fvcImage = UIImage(named: "noImageAvailable")
                    }
                } else {
//                    fvc.fvcFullView.image = UIImage(named: "noImageAvailable")
                    fvc.fvcImage = UIImage(named: "noImageAvailable")

                }
                currentPhoto = masterEntries[indexPath.row] // refer the existing object
                currentImageIndex = indexPath.row //save current object index
                fvc.fvcPhoto = masterEntries[indexPath.row] // original is currentPhoto
                
            } else {
               print("nothing in tempLink")
            }
        } else if segue.identifier == "AddImage" {
            print("Segue = AddImage")
            let dvc = segue.destinationViewController as! DetailViewController
            dvc.dvcDelegate = self  //very important
        } else if segue.identifier == "ShowDetail" {
            let dvc = segue.destinationViewController as! DetailViewController
            dvc.dvcDelegate = self
        }
    }
    
    // MARK: Functions
    
    /**
        Save image to the array list
        - Parameter photo: the photo object from DVC
    */
    func processPhotoDetails(dvcPhoto: Photo, dvcExisitngPhoto: Bool, dvcDelete: Bool, dvcImage: UIImage){
        //  1) validate the Photo object link(String) is valid (empty string)
        //  2) decide the Argument is a new or exisiting photo object
        //  3) determine to save the details or not
        
        var pl = propertyListRepresentation(dvcPhoto)   // Change Photo type to NSMutableDictionary
        let currentArray = NSMutableArray(contentsOfFile: setupPropertylist())            //load current plist
        
        if validateIsNotEmptyString(dvcPhoto) == true && dvcDelete != true{   // confirm is link is validated
            print("validated Photo")
            print("photolink is \(dvcPhoto.uRL)")
            if dvcExisitngPhoto == true {    // is a existing object
                
                currentImageIndex = currentIndexPath.row
                masterEntries[currentImageIndex!] = dvcPhoto
                
                
                pl = propertyListRepresentation(dvcPhoto)
                currentArray!.replaceObjectAtIndex(currentImageIndex!, withObject: pl)    //replace Object
                currentArray!.writeToFile(setupPropertylist(), atomically: true)
                
                print("Save exsting Photo object")
            } else {          //is a new object
                masterEntries.append(dvcPhoto)
    
                pl = propertyListRepresentation(dvcPhoto)   //pl is NSDictionar
                
                currentArray!.addObject(pl)                                               //add object
                currentArray!.writeToFile(setupPropertylist(), atomically: true)
                print("Save a new Photo object")
                
            }
        } else if dvcDelete == true {
            masterEntries.removeAtIndex(currentImageIndex!)
            let currentArray = NSMutableArray(contentsOfFile: setupPropertylist())
            currentArray!.removeObjectAtIndex(currentImageIndex!)
            currentArray!.writeToFile(setupPropertylist(), atomically: true)
            
        } else {
            print("Photo.url is an empty string, not going to save this object")
        }
        print("masterEntries now is = \(masterEntries.count)")
        currentImageIndex = nil
        currentPhoto = nil
    }
    
    /**
        Validate the photo's URL that is not an emtpy string
        - Parameter photo: the Photo object passed from DetailViewController
        - Returns: true if confirmed URL is not an empty string
    */
    func validateIsNotEmptyString (photo: Photo) -> Bool{
        print("validating photo \(photo.uRL)")
        if photo.uRL != "" {
            print("validate photo.uRL is not an empty string")
            return true
        }else{
            print("photo.uRL is an empty string")
            return false
        }
    }
    
    /**
         Setup a properlist of file for storing photo details
         - Returns: a file name where saving the photo details
     */
    func setupPropertylist() -> String {
        let path = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask,true).first! as NSString
        let file = path.stringByAppendingPathComponent("Photos.plist") // the path for store the "Photos.plist"
        return file
    }
    
    /**
        Change the Photo details into type of NSMutableDictionary
        - Returns: a Dictionary to store the title, tags and URL
     */
    func propertyListRepresentation(photo: Photo) -> NSMutableDictionary {
        let title = photo.title
        let tags  = photo.tags
        let uRL = photo.uRL
        return ["title": title,"tags": tags, "uRL": uRL]
    }
    
    /**
        Change the Object to the proper string type
        - parameter AnyObject: Photo object
        - returns: title, tags and URL in String format
     */
    func changeType(object: AnyObject) -> (String, [String], String){
        let title = object["title"] as! NSString
        let tags = object["tags"] as! NSArray
        let uRL = object["uRL"] as! NSString
        let realTitle = title as String
        let realTags = tags as! [String]
        let realURL = uRL as String
        return (realTitle,realTags,realURL)
    }
    
    /**
        load an image in imageCache(Dictionary) if available
        - parameter string: URL address
        - returns: an image store in dictionary
    */
    func imageCachingLoad(string: String) -> UIImage? {
        //1) check the image whether in cache
        if let getValue = imageCacheDict[string] {
            return getValue
        } else {
            return nil
        }
    }
    
    /**
        save an image in the imageCache(Dictionary)
    */
    func imageCachingSave(string: String, imageToStore: UIImage) {
        imageCacheDict.updateValue(imageToStore, forKey: string)
    }
    
    // MARK: Collection View
    
    // First, set the number of sections
    /**
        Counting the number of items in Photolist to show
    */
    override func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return masterEntries.count
    }
    
    // Second, set the cell
    /**
        Setup the cells by the datasource of Photo modal
    */
    override func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) ->UICollectionViewCell {
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier("photoCell", forIndexPath: indexPath) as! CollectionViewCell
        
         /*  //Old working code without background downloading
         let tempLink = masterEntries[indexPath.row].uRL
         let link = NSURL(string: tempLink)
            if let data = NSData(contentsOfURL: link!) {
                if let currentPhoto = UIImage(data: data){
                    cell.cellImage.image = currentPhoto     //image is the property of UIImageView
                }else{
                    print("invalided UIIamge")
                    cell.cellImage.image = UIImage(named: "noImageAvailable")
                }
            }else{
                print("invalided NSData")
                cell.cellImage.image = UIImage(named: "noImageAvailable")
            }
        */
        
        //new code with background downloading (has problem)
        let urlString = masterEntries[indexPath.row].uRL    //never be empty string ""
        let url = NSURL(string: urlString)  //NSURL?
        let queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0)
        let backgroundDownload = {      //Closure
            if let data = NSData(contentsOfURL: url!),
                 let currentImage = UIImage(data: data) {
                    let mainQueue = dispatch_get_main_queue()

                    dispatch_async(mainQueue, {
                        if(self.imageCachingLoad(urlString) != nil) {
//                            print("loading the image cache")
                            cell.cellImage.image = self.imageCachingLoad(urlString) //use image cache image
//                            print("imageCacheDict count = \(self.imageCacheDict.count)")
                        } else {
//                            print("load UIIamge in mainQueue")
//                            print("loading the image in background")
                            cell.cellImage.image = currentImage     //image is the property of UIImageView
                            self.imageCachingSave(urlString, imageToStore: currentImage)    //save or update the image cache
                        }
                    })
            } else {
                print("invalided NSData")
                cell.cellImage.image = UIImage(named: "noImageAvailable")
            }
        }
        dispatch_async(queue, backgroundDownload)
        
        return cell
    }
    
    // MARK: DVC Delegate
    
    /**
        Queue the image downloading in background, then show the image
     */
    func dvcBackgroundDownload(urlString: String, viewController: DetailViewController) {
        let url = NSURL(string: urlString)
        let queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0)
        
        dispatch_async(queue, {
            if let data = NSData(contentsOfURL: url!), // download some binary data, allow specific attempt to download the data
                let image = UIImage(data: data) {        // get the image from data
                let mainQueue = dispatch_get_main_queue()
                dispatch_async(mainQueue, {         // if download an image is finish, then back to the front queue and display the image
                    viewController.dvcImagePreview.image = image
                })
            } else {
                viewController.dvcImagePreview.image = UIImage(named: "noImageAvailable")
                print("Could not download image for = \(urlString)")
            }
        })
    }
    
    // MARK: FVC Delegate
    /**
        Show the previous image if swipe right in Full View controller
        - parameter fullViewController: the view controller to show an image in full screen
     */
    func previousItemFor(fullViewController: FullViewController) {
        let row = currentIndexPath.row
        let previousRow: Int
        if row == 0 { previousRow = masterEntries.count - 1 } // stop the swipe back if index is 0
        else {previousRow = row - 1}    //index - current index - 1 (reach the last element of the array (loop back)
        let indexPath = NSIndexPath(forRow: previousRow, inSection: currentIndexPath.section)
        currentIndexPath = indexPath
        print("masterEntries[previousRow] = \(masterEntries[previousRow])")
        fullViewController.fvcPhoto = masterEntries[previousRow]    //pass the object to Full view
        print(masterEntries[previousRow].uRL)
//        fullViewController.fvcImage = imageCachingLoad(masterEntries[previousRow].uRL)
        fullViewController.fvcFullView.image = imageCachingLoad(masterEntries[previousRow].uRL) //show current image to the Full view
        print("URL is \(masterEntries[previousRow].uRL)")
    }
    
    /**
        Show the next image if swipe left in Full View controller
        - parameter fullViewController: the view controller to show an image in full screen
     */
    func nextItemFor(fullViewController: FullViewController) {
        let row = currentIndexPath.row
        let nextRow: Int
        if row == masterEntries.count - 1 { nextRow = 0 }
        else {nextRow = row + 1}
        let indexPath = NSIndexPath(forRow: nextRow, inSection: currentIndexPath.section)
        currentIndexPath = indexPath
        fullViewController.fvcPhoto = masterEntries[nextRow]
        print("masterEntries[nextRow] = \(masterEntries[nextRow])")
        print("fvcView currentPhoto = \(fullViewController.fvcPhoto!)")
        print(masterEntries[nextRow].uRL)
//        fullViewController.fvcImage = imageCachingLoad(masterEntries[nextRow].uRL)
        fullViewController.fvcFullView.image = imageCachingLoad(masterEntries[nextRow].uRL) //show current image to the Full view
        print("URL is \(masterEntries[nextRow].uRL)")
    }
    
    // MARK: Navigation
    /**
        
     */
    @IBAction func swipebackSegue(sender: UIStoryboardSegue) {
        if let vc = navigationController {
            vc.popViewControllerAnimated(true)
        } else {
            self.dismissViewControllerAnimated(true, completion: nil)
        }
    }
    
    
}   // class end

