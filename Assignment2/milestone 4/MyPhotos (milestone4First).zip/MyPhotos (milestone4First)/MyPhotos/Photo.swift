//
//  Photo.swift
//  MyPhotos
//
//  Created by Grimes Wong on 18/04/2016.
//  Copyright © 2016 s2193948. All rights reserved.
//
//  Purpose: This class is for storing a photo with the title, tags and the URL link


import Foundation

class Photo {
    
    //  MARK: Properties
    var title: String
    var tags: [String]
    var uRL: String
    
    
    //  MARK: designated initialiser
    /**
        Deisignated initialiser with three parameters
        - parameters:
            - title: Title of photo
            - tags: Tags of photo
            - uRL: URL link of photo
    */
    init(title: String, tags: [String], uRL: String){
        self.title = title
        self.tags = tags
        self.uRL = uRL
    }
}
