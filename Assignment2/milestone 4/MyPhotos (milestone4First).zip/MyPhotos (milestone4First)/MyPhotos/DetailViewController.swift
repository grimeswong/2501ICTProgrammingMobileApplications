
//
//  DetailViewController.swift
//  MyPhotos
//
//  Created by s2193948 on 8/04/2016.
//  Copyright © 2016 s2193948. All rights reserved.
//  Purpose: This detailview controller can show the image with title, tags, and save it by the back button. Also can modify the current photo's details

import UIKit

protocol DetailViewControllerDelegate {
    func processPhotoDetails(dvcPhoto: Photo, dvcExisitngPhoto: Bool, dvcDelete: Bool, dvcImage: UIImage)  //  1) set Delegate (first step)
    func dvcBackgroundDownload(urlString: String, viewController: DetailViewController)
}

class DetailViewController: UIViewController, UITextFieldDelegate { //must subclass UITextFieldDelegate for dismissing the keyboard after typed in textfields
    
    
    // MARK: Properties
    
    @IBOutlet weak var dvcImagePreview: UIImageView!
    @IBOutlet weak var dvcTitleTextField: UITextField!
    @IBOutlet weak var dvcTagsTextField: UITextField!
    @IBOutlet weak var dvcURLTextField: UITextField!
    
    var dvcPhoto: Photo?
    var dvcCurrentImage: UIImage?
    var dvcExistingPhoto: Bool = false
    var dvcDelete: Bool = false
    var dvcDelegate : DetailViewControllerDelegate? = nil   //  2) set Delegate (second step)
    
    // MARK: Main UI Functions
    
  /*  override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   */
    
    /**
        Execute the data prior to show the detail view
    */
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        let nav = navigationController?.navigationBar   // change the navigation bar title to green colour
        nav!.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.greenColor()]
        if dvcPhoto == nil {    //hide the delete function if it's add Photo view
            self.navigationItem.rightBarButtonItem?.enabled = false
        }
        if dvcPhoto != nil {    // confirm whether is a new (nil) or exisiting object (photoDVC has value, eg title, tags etc..)
            dvcExistingPhoto = true    //set true for saving later 
            showDetails()       // show existing object details
        }
    }
    
    /**
        Pass the Photo object to MVC before disappear
    */
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(true)
        if dvcDelegate != nil {
            //  method to execute
            saveDetails()   //save the title, tags and URL to the photoDVC object
            if dvcPhoto != nil{ //only save the Photo obejct if Photo is exisiting object
                if (dvcCurrentImage == nil) {
                    dvcCurrentImage = UIImage(named: "noImageAvailable")
                }
                print("dvc will disapper is \(dvcCurrentImage)")
                dvcDelegate!.processPhotoDetails(self.dvcPhoto!, dvcExisitngPhoto: self.dvcExistingPhoto, dvcDelete: self.dvcDelete, dvcImage: self.dvcCurrentImage!)   // confirm the photoDVC has a object.
            }
        }
    }
    
    //For reference only as below
    //let link = "http://www.acsfoundation.com.au/bdi/assets/img/logos/Griffith3.png"
    //let linkURL = NSURL(string: link)
    //let data = NSData(contentsOfURL: linkURL!)
    
    // MARK: Function of show details
    /**
        Show the photo details by the photoDVC object pass from MasterView
    */
    func showDetails(){
        //  print("existigPhoto = \(existingPhoto)")
        dvcTitleTextField.text = dvcPhoto!.title
        dvcTagsTextField.text = dvcPhoto!.tags.joinWithSeparator(",")
        dvcURLTextField.text! = dvcPhoto!.uRL
        self.dvcImagePreview.image = dvcCurrentImage
      }
    
    /**
        Function to save the details includes title, tags and URL
    */
    func saveDetails(){
        let tempTitle : String
        let tempTags : [String]
        let tempURL : String
        tempTitle = dvcTitleTextField.text!
        print("Save title = \(tempTitle)")
        let tags = dvcTagsTextField.text!
        tempTags = tags.componentsSeparatedByString(",") // split String into array by comma
        print("Save tags = \(tempTags)")
        tempURL = dvcURLTextField.text!
        print("Save URL = \(tempURL)")
        print("dvc details are = title=\(tempTitle), tags=\(tempTags), URL=\(tempURL)")
        //  Save the photo details to the photoDVC which is ready to pass the data back
        dvcPhoto = Photo(title: tempTitle, tags: tempTags, uRL: tempURL)
    }
    
    /**
        Delete Button that delete the current Photo object if user confirm to delete
     */
    @IBAction func deletePhotoButton(sender: UIBarButtonItem) {
//        print("delete button pressed")
        var alertTitle = "this photo"
        if dvcPhoto?.title != nil {
            alertTitle = dvcPhoto!.title
        }
        //  1.)Setup UIAlertController
        let deleteAlert = UIAlertController(title: "Confirm Delete", message: "Do you want to delete \(alertTitle) logo", preferredStyle: .ActionSheet)
        //  2.)Setup UIAlertAction
        let deleteAction = UIAlertAction(title: "Delete", style: .Destructive, handler: { alertAction in
//            print("\(alertAction.title) was pressed")
            //  1.) change the delete boolean status
            self.dvcDelete = true
            //  2.) dismiss current viewcontroller and navigate back to the CollectionView Controller
            //self.navigationController?.popViewControllerAnimated(true)
            self.navigationController?.popToRootViewControllerAnimated(true)
        })
        let cancelAction = UIAlertAction(title: "Cancel", style: .Cancel, handler: nil)
        //  3.)Add alertaction to alertController
        deleteAlert.addAction(deleteAction)
        deleteAlert.addAction(cancelAction)
        //  4.)present alert viewController
        presentViewController(deleteAlert, animated: true, completion: nil)
    }
    
    // MARK: Function of dismiss the keyboard & preview image which
    /**
        Dismiss the keyboard after the user press the return key
        Preview an image by downloading in background after the user press the return button with filled correct URL in URL textfield
        - Parameter textField: the current input textfield
        - Returns: true
    */
    func textFieldShouldReturn(textField: UITextField) -> Bool { // called when 'return' key pressed. return NO to ignore.
        let uRLName = dvcURLTextField.text
        //check the URL and NSData whether are valid, if so pass MVC to download an image in background, otherwise, show the "noImageAvailale"image
        if uRLName != "" || uRLName != nil {
            print("urLname not equal empty string  or nil")
            if let checkURL = NSURL(string: uRLName!) {
                print("checkURL = \(checkURL)")
                if NSData(contentsOfURL: checkURL) != nil {
                    self.dvcDelegate?.dvcBackgroundDownload(uRLName!, viewController : self) //down image in background, when it's ready, show it on the image preview
                } else {
                    print("invalid NSData")
                    dvcImagePreview.image = UIImage(named: "noImageAvailable")
                    dvcCurrentImage = UIImage(named: "noImageAvailable")
                }
            } else {
                print("invalid NSURL")
                dvcImagePreview.image = UIImage(named: "noImageAvailable")
                dvcCurrentImage = UIImage(named: "noImageAvailable")
            }
        } else {    // if-else
            print("nothing in URL textfield, will not save")
            dvcImagePreview.image = UIImage(named: "noImageAvailable")
            dvcCurrentImage = UIImage(named: "noImageAvailable")
        }
        textField.resignFirstResponder()    // disappear keyboard (This textField argument can be include all the text field in the same view controller
        
        print("dvcCurrentImage = \(dvcCurrentImage)")
        
        return true
    }
}
