//
//  FullViewController.swift
//  MyPhotos
//
//  Created by Grimes Wong on 7/05/2016.
//  Copyright © 2016 s2193948. All rights reserved.
//

import UIKit

protocol FullViewControllerDelegate {
    func previousItemFor(viewController: FullViewController)
    func nextItemFor(viewController: FullViewController)
    func processPhotoDetails(dvcPhoto: Photo, dvcExisitngPhoto: Bool, dvcDelete: Bool, dvcImage: UIImage)
    func dvcBackgroundDownload(urlString: String, viewController: DetailViewController)
}

class FullViewController: UIViewController, DetailViewControllerDelegate {
    var fullViewDelegate: FullViewControllerDelegate!
    var fvcPhoto : Photo? = nil
    var fvcText: String = ""
    var fvcImage: UIImage? = nil
    
    
    @IBOutlet weak var fvcFullView: UIImageView!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        //self.navigationController?.navigationBarHidden = true
       // self.navigationController?.interactivePopGestureRecognizer.delegate = self
        
//        if let showImage = fvcImage {
//            fvcFullView.image = showImage
//        }
        fvcFullView.image = fvcImage
        print("fvcPhoto = \(fvcPhoto)") //only show once
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(true)
        self.navigationController?.navigationBarHidden = false
        
    }
    
    // MARK: Prepare For Segue
    
    /**
        the segue to Show the Photo details
     */
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "ShowDetail" {
            let dvc = segue.destinationViewController as! DetailViewController
            dvc.dvcPhoto = self.fvcPhoto
            dvc.dvcCurrentImage = fvcFullView.image
            dvc.dvcDelegate = self
        }
    }
    
    // MARK: DVC Delegate
    
    /**
        A bridge delegate from the Detailview controller which will pass back to the Master view
        Process the actions of save, update and delete a photo.
        - Parameter dvcPhoto: Photo object
            - dvcExisitingPhoto: whether is existing photo object
            - dvcDelete: action to process
            - dvcImage: Image to update Full view image
     */
    func processPhotoDetails(dvcPhoto: Photo, dvcExisitngPhoto: Bool, dvcDelete: Bool, dvcImage: UIImage) {
        // Pass data back to masterview controller
        fullViewDelegate.processPhotoDetails(dvcPhoto, dvcExisitngPhoto: dvcExisitngPhoto, dvcDelete: dvcDelete, dvcImage: dvcImage)
        fvcPhoto = dvcPhoto
        fvcImage = dvcImage
    }
    
    
    /**
        A bridge delegate from the Detaiview controller which will pass back to the Master view
        - Parameter urlString: URL address
            -viewController: DetailViewController
     */
    func dvcBackgroundDownload(urlString: String, viewController: DetailViewController) {
        // pass data back to masterview controller
        fullViewDelegate.dvcBackgroundDownload(urlString, viewController: viewController)
    }

    
    
    // MARK: - Navigation
    /**
        The action to swipe left
     */
    @IBAction func swipeLeft(sender: AnyObject) {
        fullViewDelegate.nextItemFor(self)
    }
    
    /**
        The action to swipe right
     */
    @IBAction func swipeRight(sender: AnyObject) {
        fullViewDelegate.previousItemFor(self)
    }
    
    /**
        THe unwind segue connection
     */
    @IBAction func swipebackSegue(sender: UIStoryboardSegue) {
        if let vc = navigationController {
            vc.popViewControllerAnimated(true)
        } else {
            self.dismissViewControllerAnimated(true, completion: nil)
        }
    }
}
