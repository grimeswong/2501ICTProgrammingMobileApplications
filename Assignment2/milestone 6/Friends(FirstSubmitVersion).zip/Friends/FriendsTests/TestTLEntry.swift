//
//  TestTLEntry.swift
//  Friends
//
//  Created by Grimes Wong on 20/05/2016.
//  Copyright © 2016 Grimes Wong s2193948. All rights reserved.
//

import XCTest
@testable import Friends

class TestTLEntry: XCTestCase {

    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }

    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measureBlock {
            // Put the code you want to measure the time of here.
        }
    }
    
    
    // MARK: Timeline Entry Tests
    
    ///
    /// Test all Empty input
    ///
    func testAllEmptyAndNilInput() {
        let testImageData : [NSData] = []   //an empty NSData file
        let testSiteData = ""
        let testAlbum = ""
        let testTLEntry = TLEntry.init(imagesData: testImageData, siteData: testSiteData, album: testAlbum)
        XCTAssertEqual(testTLEntry.imagesData!, testImageData)
        XCTAssertEqual(testTLEntry.siteData, testSiteData)
        XCTAssertEqual(testTLEntry.album, testAlbum)
        XCTAssertNotNil(testTLEntry.imagesData!)
        XCTAssertNotNil(testTLEntry.siteData)
        XCTAssertNotNil(testTLEntry.album)
    }
    
    ///
    /// Test the Timeline Image data, site data and album name
    ///
    func testImageDataSiteDataAndAlbumInput() {
        
        let url1 = NSURL(string: "http://www.acsfoundation.com.au/bdi/assets/img/logos/Griffith3.png")!
        let url2 = NSURL(string: "http://www.uq.edu.au/international/images/banners/UQlogoC-colour-M.jpg")!
        
        let testImageData = [NSData(contentsOfURL: url1)!, NSData(contentsOfURL: url2)!]
        let testSiteData = "Facebook"
        let testAlbum = "RecentPictures"
        let testTLEntry = TLEntry(imagesData: testImageData, siteData: testSiteData, album: testAlbum)
        
        for i in 0..<testTLEntry.imagesData!.count {
            XCTAssertEqual(testTLEntry.imagesData![i],testImageData[i])
        }
        XCTAssertEqual(testTLEntry.siteData, testSiteData)
        XCTAssertEqual(testTLEntry.album, testAlbum)
        
    }
    
    ///
    /// Test Setter and Getter
    ///
    func testSettersAndGetters() {
        let url1 = NSURL(string: "http://www.acsfoundation.com.au/bdi/assets/img/logos/Griffith3.png")!
        let url2 = NSURL(string: "http://www.uq.edu.au/international/images/banners/UQlogoC-colour-M.jpg")!
        let testImageData = [NSData(contentsOfURL: url1)!, NSData(contentsOfURL: url2)!]
        let testSiteData  = ["Flickr", "Facebook"]
        let testAlbum = ["lastest Photo", "Face Images"]
        let testImageDataEmpty : [NSData] = []   //an empty NSData file
        
        let testTLEntry = TLEntry(imagesData: testImageDataEmpty, siteData: "", album: "")
        
        for i in (0..<testImageData.count) {
            print(i)
            testTLEntry.imagesData?.append(testImageData[i])
            XCTAssertEqual(testTLEntry.imagesData![i], testImageData[i])
            
            for siteData in testSiteData {
                testTLEntry.siteData = siteData
                
                for album in testAlbum {
                    testTLEntry.album = album
                    
                    XCTAssertEqual(testTLEntry.siteData, siteData)
                    XCTAssertEqual(testTLEntry.album, album)
                    
                }
            }
        }
    }

    
}   //test end tag
