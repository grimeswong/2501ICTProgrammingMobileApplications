//
//  TestContact.swift
//  Friends
//
//  Created by Grimes Wong on 20/05/2016.
//  Copyright © 2016 Grimes Wong s2193948. All rights reserved.
//
//

import XCTest
@testable import Friends

class TestContact: XCTestCase {

    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }

    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measureBlock {
            // Put the code you want to measure the time of here.
        }
    }
    
    // MARK: Contact Tests
    
    /**
     Setup a properlist of file for storing photo details
     - Returns: a file name where the object is saving to
     */
    func setupPropertylist() -> String {
        let path = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask,true).first! as NSString
        let file = path.stringByAppendingPathComponent("Friends.plist") // the path for store the "Photos.plist"
        return file
    }
    
    ///
    /// Test Samples
    ///
    //    let testFirstName = "Forest"
    //    let testLastName = "Gum"
    //    let testAddress = "Run..., don't stay on the street at midnight"
    //    let testImageURL = NSURL(string: "http://www.studyinaus.com/wp-content/uploads/2014/02/logo2.gif")
    //    let testNAvailable = UIImage(named: "nIA")
    
    ///
    /// Test all Empty input
    ///
    func testAllEmptyAndNilInput() {
        let testFirstName = ""
        let testLastName = ""
        let testAddress = ""
        let testImageURL = ""
        let testSMAccount = SMAccount(id: "", type:"")
        let testTLEntry = TLEntry(imagesData: [], siteData: "", album: "")
        let testContact = Contact(firstName: testFirstName, lastName: testLastName, address: testAddress, imageURL: testImageURL, sMAccount: testSMAccount, tlEntry: testTLEntry)
        
        XCTAssertEqual(testContact.firstName, testFirstName)
        XCTAssertEqual(testContact.lastName, testLastName)
        XCTAssertEqual(testContact.address, testAddress)
        XCTAssertEqual(testContact.imageURL, testImageURL)
        XCTAssertEqual(testContact.sMAccount, testSMAccount)
        XCTAssertEqual(testContact.tlEntry, testTLEntry)
    }
    
    
    ///
    /// Test the title name, tags and uRL in normal correct input scenarios
    ///
    func testNameAndAddressInput() {
        let testFirstName = "Forrest"
        let testLastName = "Gump"
        let testAddress = "Run..., don't stay on the street at midnight"
        let testContact = Contact(firstName: testFirstName, lastName: testLastName, address: testAddress)
        
        XCTAssertEqual(testContact.firstName, testFirstName)
        XCTAssertEqual(testContact.lastName, testLastName)
        XCTAssertEqual(testContact.address, testAddress)
        
    }
    
    ///
    /// Test Setter and Getter
    ///
    func testSettersAndGetters() {
        let testFirstNames = ["Anne", "Lin Wah", "David"]
        let testLastNames = ["Billington", "Topor", "Nguyen"]
        let testAddress = ["Ellis", "William", "Mary"]
        let testImageURL = ["a", "b", "c", "d"]
        let testSMAccount = [SMAccount(id:"a", type:"b"),SMAccount(id:"c", type:"d"),SMAccount(id:"e", type:"f")]
        let testTLEntry = [TLEntry(imagesData: [], siteData: "a", album: "b"), TLEntry(imagesData: [], siteData: "c", album: "d"),TLEntry(imagesData: [], siteData: "e", album: "f")]
        
        let contact = Contact(firstName: "", lastName: "", address: "")
        for first in testFirstNames {
            contact.firstName = first
            
            for last in testLastNames {
                contact.lastName = last
                
                for address in testAddress {
                    contact.address = address
                    
                    for imageURL in testImageURL {
                        contact.imageURL = imageURL
                        
                        for smaAccount in testSMAccount {
                            contact.sMAccount = smaAccount
                            
                            for tlEntry in testTLEntry {
                                contact.tlEntry = tlEntry
                                
                                XCTAssertEqual(contact.firstName, first)
                                XCTAssertEqual(contact.lastName, last)
                                XCTAssertEqual(contact.address, address)
                                XCTAssertEqual(contact.imageURL, imageURL)
                                XCTAssertEqual(contact.sMAccount, smaAccount)
                                XCTAssertEqual(contact.tlEntry, tlEntry)
                            }
                        }
                    }
                }
            }
        }
    }


} //Test end tag
