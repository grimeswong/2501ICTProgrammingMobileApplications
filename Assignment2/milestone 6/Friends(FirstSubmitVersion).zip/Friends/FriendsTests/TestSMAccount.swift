//
//  TestSMAccount.swift
//  Friends
//
//  Created by Grimes Wong on 20/05/2016.
//  Copyright © 2016 Grimes Wong s2193948. All rights reserved.
//

import XCTest
@testable import Friends

class TestSMAccount: XCTestCase {

    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }

    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measureBlock {
            // Put the code you want to measure the time of here.
        }
    }
    
    // MARK: Social Meida Account Tests
    
    ///
    /// Test all Empty input
    ///
    func testAllEmptyAndNilInput() {
        let testSMAID = ""
        let testSMAType = ""
        let testSMAccount = SMAccount(id: "", type: "")
        XCTAssertEqual(testSMAccount.smaID, testSMAID)
        XCTAssertEqual(testSMAccount.smaType, testSMAType)
        XCTAssertNotNil(testSMAccount.smaID)
        XCTAssertNotNil(testSMAccount.smaType)
    }
    
    ///
    /// Test the Social Media Account ID and Type
    ///
    func testIDAndTypeInput() {
        let testSMAID = "Grimes"
        let testSMAType = "Flickr"
        let testSMAccount = SMAccount(id: testSMAID, type: testSMAType)
        XCTAssertEqual(testSMAccount.smaID, testSMAID)
        XCTAssertEqual(testSMAccount.smaType, testSMAType)
        
    }
    
    ///
    /// Test Setter and Getter
    ///
    func testSettersAndGetters() {
        let testSMAID  = ["Anne", "Lin Wah", "David"]
        let testSMAType = ["Billington", "Topor", "Nguyen"]
        
        let smaAccount = SMAccount(id: "", type: "")
        for id in testSMAID {
            smaAccount.smaID = id
            
            for type in testSMAType {
                smaAccount.smaType = type
                
                XCTAssertEqual(smaAccount.smaID, id)
                XCTAssertEqual(smaAccount.smaType, type)
                
            }
        }
    }
    

}   //test end tag
