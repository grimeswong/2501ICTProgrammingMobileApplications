//
//  FullViewController.swift
//  Friends
//
//  Created by Grimes Wong on 24/05/2016.
//  Copyright © 2016 Grimes Wong s2193948. All rights reserved.
//
//  Show the collection of Photo that can swipe left or right to navigate the photos

import UIKit

class FullViewController: UIViewController {
    
    //MARK: Main View
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        
        
    }

}
