//
//  ContactList.swift
//  Friends
//
//  Created by Grimes Wong on 20/05/2016.
//  Copyright © 2016 Grimes Wong s2193948. All rights reserved.
//  Purpose: This class create an array to store the new contactlistEntry object
//

import Foundation

class ContactList: NSObject {
    
    
    // MARK: Properties
    /**
     *  A array to store the Contact
     */
    dynamic var entries : [Contact] = []  //create an empty array
 
    
}