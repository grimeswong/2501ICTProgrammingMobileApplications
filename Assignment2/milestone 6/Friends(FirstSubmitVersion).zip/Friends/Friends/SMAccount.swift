//
//  SMAccount.swift
//  Friends
//
//  Created by Grimes Wong on 20/05/2016.
//  Copyright © 2016 Grimes Wong s2193948. All rights reserved.
//  Purpose: This class is for storing the Social Account which included account's ID and Type such as Flick, Facebook etc..
//

import Foundation

class SMAccount: NSObject {
    dynamic var smaID: String = ""
    dynamic var smaType: String = ""    // Can use Enum Case 1.)
    
    init(id: String, type: String) {
        self.smaID = id
        self.smaType = type
    }
    
    // MARK: Function
    
    /**
     Converter the current properties to the NS propertyList format
     - returns: Dictionary format of Contact
     */
    func propertyListRepresentation() -> NSDictionary {
        return [
            "smaID": self.smaID,
            "smaType": self.smaType
        ]
    }
    
}
