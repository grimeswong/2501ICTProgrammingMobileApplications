//
//  Contact.swift
//  Friends
//
//  Created by Grimes Wong on 20/05/2016.
//  Copyright © 2016 Grimes Wong s2193948. All rights reserved.
//  Purpose: The model to store the user first name, last name, address, image file, image URL, Social Media Account and Time Line Entry

import Foundation
import UIKit        //import UIKit for support the UIImage file

class Contact: NSObject { // To fulfill the Key/Value Compliant
    
    dynamic var firstName: String = ""
    dynamic var lastName: String = ""
    dynamic var address: String = ""
    dynamic var imageURL: String? = ""
    dynamic var imageData: NSData? = nil       // Store image Data
    dynamic var sMAccount: SMAccount? = nil // Social Media Account
    dynamic var tlEntry: TLEntry? = nil     // Time Line Entry
    
    init(firstName: String, lastName: String, address: String, imageURL: String? = "", imageData: NSData? = nil, sMAccount: SMAccount? = nil, tlEntry: TLEntry? = nil) { //image, imageURL, smAccount and tlEntry can be nil (No parameters are in)
        
        self.firstName = firstName
        self.lastName = lastName
        self.address = address
        self.imageURL = imageURL
        self.imageData = imageData
        self.sMAccount = sMAccount
        self.tlEntry = tlEntry
    }
    
    // MARK: Function
    
    /**
     Converter the current properties to the NS propertyList format
     - returns: Dictionary format of Contact
     */
    func propertyListRepresentation() -> NSDictionary {
        
        return [                                                // Warning: must use square bracket for store data into property list
            "firstName": self.firstName,
            "lastName": self.lastName,
            "address": self.address,
            //"imageURL": self.imageURL?.absoluteURL ?? "",    //Nil Coalescing Operator, ALT: imageURL?.absoluteString
            "imageURL": self.imageURL ?? "",
            "imageData": self.imageData ?? NSData(),
            "sMAccount": self.sMAccount?.propertyListRepresentation() ?? [:],   // empty Dictionary
            "tlEntry": self.tlEntry?.propertyListRepresentation() ?? [:]    //empty Dictionary
        ]
    }
    
    /**
     This function will return the full name
     - Returns: the first name and last name
     */
    func showfullName() ->String { //return type:String
            let tempFullDetails = "\(firstName) \(lastName)"
            return tempFullDetails
    }
    
}
