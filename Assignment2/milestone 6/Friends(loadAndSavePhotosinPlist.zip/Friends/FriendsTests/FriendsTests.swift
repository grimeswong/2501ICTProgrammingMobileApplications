//
//  FriendsTests.swift
//  FriendsTests
//
//  Created by Grimes Wong on 19/05/2016.
//  Copyright © 2016 Grimes Wong s2193948. All rights reserved.
//

import XCTest
@testable import Friends

class FriendsTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        FlickrAPIKey = "cb53fc85826cceb68025a77e4fa5a18a"
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measureBlock {
            // Put the code you want to measure the time of here.
        }
    }
    
    func testLatestPhotos() {
        let lastestPhotos = latestFlickrPhotos()
        XCTAssertNotNil(lastestPhotos)
        XCTAssertEqual(lastestPhotos?.count, FlickrDefaultMaximumResults)   //Maxium 50 photos can be downloaded
    }
    
    func testPhoto() {
        let photos = photosForUser("strictfunctor")
        XCTAssertNotNil(photos)
        XCTAssert(photos?.count > 0)
    }
    
    func testPhotoImage() {
        let photos = photosForUser("strictfunctor")
        XCTAssertNotNil(photos)
        XCTAssert(photos!.count > 0)
        let photo = photos!.first!
        let photoURLString = urlString(photo)
        XCTAssertNotNil(photoURLString)
        let url = NSURL(string: photoURLString!)
        XCTAssertNotNil(url)
        let photoData = NSData(contentsOfURL: url!)
        XCTAssertNotNil(photoData)
        let image = UIImage(data: photoData!)
        XCTAssertNotNil(image)
    }
    
}
