//
//  TLEntry.swift
//  Friends
//
//  Created by Grimes Wong on 20/05/2016.
//  Copyright © 2016 Grimes Wong s2193948. All rights reserved.
//  Purpose: This class is for storing the TimeLine of Contact which included images(images data), site data, and album
//

import Foundation

class TLEntry: NSObject {
    dynamic var imagesData: [NSData]? = []  // initialize an empty array of NSData, "dynamic" is for KVO that can access the property
    dynamic var siteData: String = ""
    dynamic var album: String = ""
    
    init(imagesData: [NSData]? = [], siteData: String, album: String) {
        self.imagesData = imagesData
        self.siteData = siteData
        self.album = album
    }
    
    // MARK: Function
    
    /**
     Converter the current properties to the NS propertyList format
     - returns: Dictionary format of Contact
     */
    func propertyListRepresentation() -> NSDictionary {
        
        let imagesArray : NSMutableArray = []
        if imagesData != nil {
            for item in imagesData! {
                let itemPL = item as NSData
                imagesArray.addObject(itemPL)
            }
        }
        
        return [
            "imagesData": imagesArray ?? [], // return empty array of NSData if it has no value
            "siteData": self.siteData,
            "album": self.album
        ]
    }
}
