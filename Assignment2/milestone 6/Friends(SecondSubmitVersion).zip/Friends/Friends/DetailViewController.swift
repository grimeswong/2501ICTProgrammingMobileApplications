//
//  DetailViewController.swift
//  Friends
//
//  Created by Grimes Wong on 19/05/2016.
//  Copyright © 2016 Grimes Wong s2193948. All rights reserved.
//
//  Purpose: This view controller show the details of contact, social media account and




protocol DetailViewControllerDelegate {
    func processContactDetails(contact: Contact, viewController: DetailViewController)
    func dvcBackgroundDownload(imageURL: String, viewController: DetailViewController)
}

import UIKit

class DetailViewController: UITableViewController, MapViewControllerDelegate, WebViewControllerDelegate, CollectionViewControllerDelegate {
    
    //MARK: Properties
    var dvcContact: Contact? = nil       //The current Contact object
    var dvcImage : UIImage? = nil        //The current imageView image
    var dvcDelegate: DetailViewControllerDelegate? = nil   //DVC delegate
    var dvcTLEntry: TLEntry? = nil

    
    //Personal Detail Section
    @IBOutlet weak var firstNameTextField: UITextField!
    @IBOutlet weak var lastNameTextField: UITextField!
    @IBOutlet weak var addressTextField: UITextField!
    
    //Social Media Section
    @IBOutlet weak var webSiteTextField: UITextField!
    @IBOutlet weak var photoAlbumTextField: UITextField!
    
    //Picture Section
    @IBOutlet weak var imageURLTextField: UITextField!
    @IBOutlet weak var dvcImageView: UIImageView!
    
    // MARK: Main Views Functions
    override func viewDidLoad() {
        super.viewDidLoad()
        print("dvcContact?.sMAccount?.count = \(dvcContact?.sMAccount?.count)")
        if (dvcContact?.sMAccount?.count == 0) {
            dvcContact?.sMAccount?.append(SMAccount(id: "", type: "Web"))
            dvcContact?.sMAccount?.append(SMAccount(id: "", type: "PhotoAlbum"))
            
            print("dvcContact?.sMAccount?[0] = \(dvcContact?.sMAccount?[0])")
        }
        self.firstNameTextField.text = dvcContact?.firstName
        self.lastNameTextField.text = dvcContact?.lastName
        self.addressTextField.text = dvcContact?.address
        self.imageURLTextField.text = dvcContact?.imageURL
        self.webSiteTextField.text = dvcContact?.sMAccount?[0].smaID ?? ""
        if dvcContact?.sMAccount?.count > 1 {
            self.photoAlbumTextField.text = dvcContact?.sMAccount?[1].smaID ?? ""
        }
        self.dvcImageView.image = dvcImage
    }

//    override func didReceiveMemoryWarning() {
//        super.didReceiveMemoryWarning()
//        // Dispose of any resources that can be recreated.
//    }
    
    override func viewWillDisappear(animated: Bool) {
        saveDetails()
        self.dvcDelegate?.processContactDetails(dvcContact!, viewController: self)
    }
    
    //MARK: Segue
    
    /**
     the segue to Show the Map, Web and Photo Album
     */
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "showAddress" {
            let mvc = segue.destinationViewController as! MapViewController
            mvc.mvcAddress = self.dvcContact?.address ?? ""   //if a new contact, the address will be empty for avoid force unwrapp option
            mvc.mvcAddress = addressTextField.text!
            mvc.mvcDelegate = self  //very important
        } else if segue.identifier == "showWeb" {
            let wvc = segue.destinationViewController as! WebViewController
            wvc.wvcURL = self.webSiteTextField.text!
            self.dvcContact?.sMAccount?[0].smaType = "Web"
            wvc.wvcDelegate = self
            
        } else if segue.identifier == "showCollection" { //CollectionViewCollection
            let cvc = segue.destinationViewController as! CollectionViewController
            cvc.cvcDelegate = self
            //cvc.cvcTLEntry = dvcContact?.sMAccount?.tlEntry
            cvc.cvcAlbum = photoAlbumTextField.text!
            
        }
        
    }   //Segue tag end
    
    
    
    //MARK: Functions
    
    /**
        Function to save the Contact details
     */
    func saveDetails(){
        let firstName = firstNameTextField.text ?? ""
        let lastName = lastNameTextField.text ?? ""
        let address = addressTextField.text ?? ""
        let imageURL = imageURLTextField.text ?? ""
        var imageData = NSData()
        if dvcImage != nil {
            imageData = UIImagePNGRepresentation(self.dvcImage!)!
        }
        let websmaId = webSiteTextField.text!
        let websmaType = "Web"
        
        
        dvcContact = Contact(firstName: firstName, lastName: lastName, address: address, imageURL: imageURL, imageData: imageData, sMAccount: [SMAccount(id: websmaId, type: websmaType)])
        print("Detail: Saving Details")
        print(dvcContact?.sMAccount?[0].smaID)
        print("Detail: dvcContact = \(dvcContact?.sMAccount?[0].smaID)")
    }
    
    /**
        Dismiss the keyboard after the user press the return key
        - Parameter textField: the current input textfield
        - Returns: true
     */
    func textFieldShouldReturn(textField: UITextField) -> Bool { // called when 'return' key pressed. return NO to ignore.
        let urlString = imageURLTextField.text
        textField.resignFirstResponder()    // disappear keyboard (This textField argument can be include all the text field in the same view controller
        self.dvcDelegate?.dvcBackgroundDownload(urlString!, viewController: self)
        return true
    }
    
    // MARK: MVC Delegate
    /**
        For update the current address in address Textfield
     */
    func saveAddress(contactAddress: String, viewController: MapViewController) {
        addressTextField.text  = contactAddress
    }
    
    // MARK: WVC Delegate
    /**
        For update the current social media website address
     */
    func saveWebURL(sMAccount: SMAccount, viewController: WebViewController) {
        webSiteTextField.text = sMAccount.smaID
        dvcContact?.sMAccount?[0].smaID = sMAccount.smaID   //updated the current contact
        dvcContact?.sMAccount?[0].smaType = sMAccount.smaType
        
    }
    
    // MARK: CVC Delegate
    /**
        For update the TLEnry photos album
     */
    func saveCVCTLEntry(cvcTLEntry: TLEntry, viewcontroller: CollectionViewController) {
        dvcTLEntry = cvcTLEntry
        //dvcContact?.sMAccount?.tlEntry = dvcTLEntry
        print("DVC: dvcTLEntry.album = \(dvcTLEntry?.album)" )
        print("DVC: dvcimagedata.count = \(dvcTLEntry?.imagesData?.count)" )
    }
    
    
    
    
}   // DetailViewController end tag

