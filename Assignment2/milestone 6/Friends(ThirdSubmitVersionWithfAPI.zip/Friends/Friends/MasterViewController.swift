//
//  MasterViewController.swift
//  Friends
//
//  Created by Grimes Wong on 19/05/2016.
//  Copyright © 2016 Grimes Wong s2193948. All rights reserved.
//
//  Purpose: A Masterview controller to show the contacts list which include the contact details, social media account and timeline entries

import UIKit

class MasterViewController: UITableViewController, DetailViewControllerDelegate {
    
    //  MARK: Properties

    var detailViewController: DetailViewController? = nil
    
    var contactEntries = ContactList().entries // A array list to store contacts
    var currentContact : Contact? = nil        // Current Contact object
    var currentIndexPath = NSIndexPath()       // Current Index Path
    var newContact = false                  // false for existing, true for new contact
    var contactIndex : Int = 0
    

    override func viewDidLoad() {
        super.viewDidLoad()
        print("Master: viewDidLoad...")
        self.navigationItem.leftBarButtonItem = self.editButtonItem()
        
        //  load exisiting property list
        let array = NSMutableArray(contentsOfFile: setupPropertylist()) //NSArray in propertylist
        if array != nil {
            print("array.count = \(array!.count)")
            print("plist is exsiting")
            print("plist path is = \(setupPropertylist())")
            
            for element in array! {
                let changeToNormalString = changeType(element as! NSDictionary)
                
                contactEntries.append(Contact(firstName: changeToNormalString.0, lastName: changeToNormalString.1, address: changeToNormalString.2, imageURL: changeToNormalString.3, imageData: changeToNormalString.4, sMAccount: changeToNormalString.5))
                
            }
            /*  tester */
//            for i in (0..<contactEntries.count) {
//                print("ViewDidLoad smaID = \(contactEntries[i].sMAccount?.smaID)")
//            }
            /* tester */
          
            
        } else {    // plist is nil, put samples in
            // Sample entries
            let con1 = Contact(firstName: "Grimes", lastName: "Wong", address: "Nottingham Street, Calamvale, QLD, Australia", imageURL: "http://images4.fanpop.com/image/photos/18800000/Ewan-McGregor-Grimes-Black-Hawk-Down-black-hawk-down-18874867-300-200.jpg", sMAccount: [SMAccount(id: "http://www.yahoo.com.au", type: "Website")])
            
            let con2 = Contact(firstName: "Karen", lastName: "Yip", address: "Sunnybank Plaza, Sunnybank, QLD", imageURL: "https://image.spreadshirtmedia.com/image-server/v1/compositions/2345674/views/1,width=235,height=235,appearanceId=2,backgroundColor=f9f9f9,version=1440417743/Black-Skull-and-Crossbones-Men.jpg", sMAccount: [SMAccount(id: "http://www.google.com.au", type: "Website")])
            let con3 = Contact(firstName: "Rex", lastName: "Wong", address: "Griffith University, Nathan Campus", imageURL: "http://www.polyvore.com/cgi/img-thing?.out=jpg&size=l&tid=25307776",sMAccount: [SMAccount(id: "http://www.yahoo.com.hk", type: "Website")])
            let con4 = Contact(firstName: "Fake", lastName: "You", address: "Treasury Casino, Brisbane, qld, 4000", imageURL: "", sMAccount: [SMAccount(id: "http://www.weatherzone.com.au/nt/alice-springs/alice-springs", type: "Website")])
            
            let pl1 = con1.propertyListRepresentation()
            let pl2 = con2.propertyListRepresentation()
            let pl3 = con3.propertyListRepresentation()
            let pl4 = con4.propertyListRepresentation()
            let arrayNew : NSMutableArray = []   //create an array
            arrayNew.addObject(pl1)
            arrayNew.addObject(pl2)
            arrayNew.addObject(pl3)
            arrayNew.addObject(pl4)
            arrayNew.writeToFile(setupPropertylist(), atomically: true)      //write data to propertyList
            
            //  load data out
            for element in arrayNew {
                let changeToNormalString = changeType(element as! NSDictionary)
                contactEntries.append(Contact(firstName: changeToNormalString.0, lastName: changeToNormalString.1, address: changeToNormalString.2, imageURL: changeToNormalString.3, imageData: changeToNormalString.4, sMAccount: changeToNormalString.5))
            }

        }
        
        //  Loading thumbnail photo
        
        for i in 0..<contactEntries.count {
            
            if contactEntries[i].imageURL != "" {   // if imageURL has string
                if let validURL = self.contactEntries[i].imageURL,
                    let validNSURL = NSURL(string: validURL),
                    let validNSData = NSData(contentsOfURL:  validNSURL) {
                    self.contactEntries[i].imageData = validNSData
                    print("Master: CurrentImage is downloading...")
                } else { //if not a valid link
                    self.contactEntries[i].imageData = UIImagePNGRepresentation(UIImage(named:"nIA")!)
                    print("Master: CurrentImage is No image Available")
                }
            } else {    // no imageURL avaible, noImageAvailable image will be store
                contactEntries[i].imageData = UIImagePNGRepresentation(UIImage(named:"nIA")!)
            }
        }
        
    }   //viewDidLoad end tag

    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        print("Master: viewWillAppear...")
        print("Master: contactEntries now is = \(contactEntries.count)")
        tableView.reloadData()
    }

//    override func didReceiveMemoryWarning() {
//        super.didReceiveMemoryWarning()
//        Dispose of any resources that can be recreated.
//    }

    // MARK: - Segues
    /**
         Show existing contact by segue "showDetail"
         Add contact by segue "addContact"
     */
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "showDetail" {
                let indexPath = self.tableView.indexPathForSelectedRow
                currentIndexPath = indexPath!                        //Keep the indexpath when push the view controller
                print("Master: Current Indexpath = \(currentIndexPath)")
                print("Master: Current Indexpath row = \(currentIndexPath.row)")
                currentContact = contactEntries[indexPath!.row]      //Set the currentContact in Masterview property
                contactIndex = indexPath!.row
                
//                Use the below segue if use navigation bar to the next view controller
//                let controller = (segue.destinationViewController as! UINavigationController).topViewController as! DetailViewController
                //Use the below segue if directly navigate to the next view controler
                let controller = segue.destinationViewController as! UITableViewController as! DetailViewController
                controller.dvcDelegate = self  //very important for control dvc delegate
                controller.dvcContact = currentContact               //Set the dcContact to currentContact in MasterView (Current Contact object)
                controller.dvcImage = UIImage(data: (currentContact?.imageData)!)
    
        } else if segue.identifier == "addContact" {
                let dvc = segue.destinationViewController as! DetailViewController
                dvc.dvcDelegate = self  //very important for control dvc delegate
                newContact = true
        
        }
            
    } //prepareForSegue end tag
    
    // MARK: Functions
    
    /**
        Setup a properlist of file for storing Contact details
        - Returns: a file name where saving the Contact details
        */
    func setupPropertylist() -> String {
        let path = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask,true).first! as NSString
        let file = path.stringByAppendingPathComponent("Friends.plist") // the path for store the "Friends.plist"
        return file
    }
    
    /**
        Change the Object to the appropriate string type or class type
        - parameter NSDictionary: Contact (NSDictionary)
        - returns: firstName, lastName, address, imageURL, imagedata, SocialMediaAccount
     */
    func changeType(object: NSDictionary) -> (String, String, String, String, NSData, [SMAccount]){
        let firstName = object["firstName"] as! NSString
        let lastName = object["lastName"] as! NSString
        let address = object["address"] as! NSString
        let imageURL = object["imageURL"] as! NSString
        let realImageData = object["imageData"] as! NSData
        let sMAccount = object["sMAccount"] as? NSMutableArray
        
        let realFirstName = firstName as String
        let realLastName = lastName as String
        let realAddress = address as String
        let realImageURL = imageURL as String
        
        /* tester for type casting */
//        print("changeType: sMAccount.count = \(sMAccount?.count)")
        
        var realsMAccount : [SMAccount] = []    //declare an emtyp SMA array for temporarily store data
        var realtlEntry : TLEntry? = nil        //Only one account
        
        if sMAccount != nil {
            for singleSMA in sMAccount! {
//                print("CT: sMAccount = \(sMAccount)")
//                print("CT: SMAID = \(singleSMA["smaID"])")
//                print("CT: SMATypte = \(singleSMA["smaType"])")
                
                if singleSMA["tlEntry"] != nil {
                    
                    let tempTLEntry = singleSMA["tlEntry"] as! NSDictionary
//                    print("CT: tempTLEntry = \(tempTLEntry)")
//                    print("CT: siteData = \(tempTLEntry["siteData"])")
//                    print("CT: album = \(tempTLEntry["album"])")
//                    print("CT: imagesData = \(tempTLEntry["imagesData"])")
                    var realImagesData : [NSData] = []
                    
//                    print("CT images Array = \(imagesArray)")
                    
                    if (tempTLEntry["imagesData"] != nil) {
                        print("CT: imagesData is not nil")
                        realtlEntry = TLEntry(imagesData: [], siteData: "", album: "")
                        let temp = tempTLEntry["imagesData"] as! [NSData]
                        for tempImagesData in temp {
//                            print("CT: imagesData are = \(tempImagesData)")
                            realImagesData.append(tempImagesData)
                        }
                    } else {
                        print("imagesData did not loaded")
                    }
                    //Store tlEntry for each SMAccount
                    realtlEntry = TLEntry(imagesData: realImagesData, siteData: tempTLEntry["siteData"] as? String ?? "", album: tempTLEntry["album"] as? String ?? "")
                    
                }
                //Store the whole SMAccount and return to Contact
                realsMAccount.append(SMAccount(id: (singleSMA["smaID"] as? String)!, type: (singleSMA["smaType"] as? String)!, tlEntry: realtlEntry))
            }
        }
    
        return (realFirstName,realLastName,realAddress,realImageURL,realImageData, realsMAccount)
    }
    
    // MARK: DVC Delegates
    
    /**
        Save Contact detail to the array list (Contact.entries) and proper List
        - parameter contact: Contact Details
        - parameter viewController: Detail View Controller
     */
    func processContactDetails(contact: Contact, viewController: DetailViewController) {
        //  1) at least one textfield is entered either in first or last name (Validation)
        //  2) decide the Argument is a new or exisiting Contact object by whether is new Contact (newContact = true or false)
        //  3) process Contact object for both Contact List and Properlist
        
        let pl = contact.propertyListRepresentation()   // Change Contact type to NSMutableDictionary
        let currentArray = NSMutableArray(contentsOfFile: setupPropertylist())            //load current plist
        
        // pre-condition for saving Contact
        // Must have first name or lastname
        if contact.firstName != "" || contact.lastName != "" {
            if newContact == false { // Existing Contact object (if indexPath is existing means clicking one of the cell)
                print("Master: Saving existing Contact Object")
                print("Master: contactIndex = \(contactIndex)")
                print("Master: currentContact =  \(currentContact)")
                print("Master: currentIndexPath.row = \(currentIndexPath.row)")
                
//                print("Master: sma.count = \(contactEntries[5].sMAccount?.count)")
//                print("Master: smaID is = \(contactEntries[5].sMAccount?[0].smaID)")
//                print("Master: smaID is = \(contactEntries[5].sMAccount?[0].smaType)")
              
                contactEntries[contactIndex] = contact                              //Replace Contact to Contact List
                currentArray!.replaceObjectAtIndex(contactIndex, withObject: pl)    //load list and replace contact
                currentArray!.writeToFile(setupPropertylist(), atomically: true)    //write to file
                
            } else if newContact == true {    // new Contact
                print("Master: Saving a new Contact Object")
                print("Master: contactIndex = \(contactIndex)")
                print("Master: currentContact =  \(currentContact)")
                
                contactEntries.append(contact)                                       //Add Contact to Contact List
                currentArray!.addObject(pl)                                          //add object
                currentArray!.writeToFile(setupPropertylist(), atomically: true)     //write to file
                
                contactIndex = contactEntries.count - 1     //update the contact index when navigate to third or further view controller and back the second
                
            }
        }
        newContact = false  //set default   // if go to the third view controller
        
    }
    
    /**
        This function loading the image in the background by the string in the textfield, then show the image in the image view
        - parameter imageURL: URL address (string)
        - parameter viewController: Detail View Controller
     */
    func dvcBackgroundDownload(imageURL: String, viewController: DetailViewController) {
        //setup downloading background image
        let queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0)
        let backgroundDownload = {
            
            if let validNSURL = NSURL(string: imageURL),
                let validNSData = NSData(contentsOfURL: validNSURL) {
                    let image = UIImage(data: validNSData)
                 //   viewController.dcContact?.imageData = validNSData //store the imageData in the dcContact.imageData (Object)
                    print("DVC Image is downloading...")
                    let mainQueue = dispatch_get_main_queue()
                    dispatch_async(mainQueue, {
                        print("back to main queue")
                        viewController.dvcImage = image
                        viewController.dvcImageView.image = image
                    })
                } else { //if not a valid link
                    print("CurrentImage is No image Available")
                   // viewController.dcContact?.imageData = UIImagePNGRepresentation(UIImage(named:"nIA")!)//store the imageData in the dcContact.imageData (Object)
                    let mainQueue = dispatch_get_main_queue()
                    dispatch_async(mainQueue, {
                        viewController.dvcImage = UIImage(named: "nIA")
                        viewController.dvcImageView.image = UIImage(named: "nIA")
                    })
                }
        }
        dispatch_async(queue, backgroundDownload)
    }


    // MARK: - Table View

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contactEntries.count
    }

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("ContactCell", forIndexPath: indexPath)
        cell.textLabel!.text = contactEntries[indexPath.row].showfullName() //show the full name in cell
        cell.imageView?.image = UIImage(data: contactEntries[indexPath.row].imageData!)               //show the thumbnail image
        //print("Master: Cell loading...")
        
        return cell
    }
    
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    ///
    /// Functions of deletion
    ///
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            contactEntries.removeAtIndex(indexPath.row)                             //Remove Contact from Contact List
            
            let currentArray = NSMutableArray(contentsOfFile: setupPropertylist())  //load propertlist
            currentArray!.removeObjectAtIndex(indexPath.row)                        //Remove Contact from Properlist
            currentArray!.writeToFile(setupPropertylist(), atomically: true)        //Write to properlist
            
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
            
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
        }
    }


}

