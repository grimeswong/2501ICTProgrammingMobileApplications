//
//  CollectionViewCell.swift
//  Friends
//
//  Created by Grimes Wong on 24/05/2016.
//  Copyright © 2016 Grimes Wong s2193948. All rights reserved.
//
//  Purpose: A class for reuse the cellImage

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var cellImage: UIImageView!
    
}
