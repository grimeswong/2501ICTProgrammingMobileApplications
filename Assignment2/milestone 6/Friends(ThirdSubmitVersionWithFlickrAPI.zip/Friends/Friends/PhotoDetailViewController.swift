//
//  PhotoDetailViewController.swift
//  Friends
//
//  Created by Grimes Wong on 24/05/2016.
//  Copyright © 2016 Grimes Wong s2193948. All rights reserved.
//
//  Show the details of Photo

import UIKit

protocol PhotoDetailViewControllerDelegate {
    
    func savePhoto(pvcImageData: NSData, viewController: PhotoDetailViewController)
    func dvcBackgroundDownload(urlString: String, viewController: PhotoDetailViewController)
    
}

class PhotoDetailViewController: UIViewController {
    
    var pvcTLEntry : TLEntry? = nil
    var pvcImageData : NSData? = nil
    var pvcCurrentImage: UIImage? = nil
    var pvcExistingPhoto: Bool = false
    var pvcDelete: Bool = false
    var pvcDelegate : PhotoDetailViewControllerDelegate? = nil   //  2) set Delegate (second step)

    @IBOutlet weak var pvcImagePreview: UIImageView!
    @IBOutlet weak var pvcPhotoURLTextField: UITextField!
    
    //MARK: Main View
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        pvcImagePreview.image = pvcCurrentImage
        
        
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(true)
        //1) Save photo
        if pvcImageData != nil {
            self.pvcDelegate?.savePhoto(pvcImageData!, viewController: self)
            print("PVC: Saving imagedata...")
        }
        
    }
    
    /**
     Dismiss the keyboard after the user press the return key
     - Parameter textField: the current input textfield
     - Returns: true
     */
    func textFieldShouldReturn(textField: UITextField) -> Bool { // called when 'return' key pressed. return NO to ignore.
        let urlString = pvcPhotoURLTextField.text
        textField.resignFirstResponder()    // disappear keyboard (This textField argument can be include all the text field in the same view controller
        self.pvcDelegate?.dvcBackgroundDownload(urlString!, viewController: self)
        return true
    }
}
