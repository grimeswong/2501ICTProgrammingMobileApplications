//
//  WebViewController.swift
//  Friends
//
//  Created by Grimes Wong on 22/05/2016.
//  Copyright © 2016 Grimes Wong s2193948. All rights reserved.
//
//  Purpose: Show the website when user type or store a valid URL

import UIKit

protocol WebViewControllerDelegate {
    
    func saveWebURL(smaAccount:SMAccount, viewController: WebViewController)
}

protocol WebViewDelegate {
    
    func webViewDidFinishLoad(webView: UIWebView)
}

class WebViewController: UIViewController, UIWebViewDelegate {
    
    @IBOutlet weak var urlTextField: UITextField!
    @IBOutlet weak var webView: UIWebView!
    @IBOutlet weak var wvcActivityIndicator: UIActivityIndicatorView!
    var wvcURL: String = ""
    var wvcDelegate: WebViewControllerDelegate? = nil
    var wvcWebViewDelegate: WebViewDelegate? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        webView.delegate = self
        urlTextField.text = wvcURL  //show the URL
        loadWebSite()
        
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(true)
        self.wvcDelegate?.saveWebURL(SMAccount(id: wvcURL,type: "Website"), viewController: self)
    }
    
    // MARK: Functions
    
    /**
        This function can display a web page after enter a valid URL address
     - parameter textField: URL textfield
     - returns: true
     */
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()    //press the return button
        let urlAddress = urlTextField.text!
        wvcURL = urlAddress
        loadWebSite()
        return true
        //  Setup for resign the keyboard when press the "return button"
        //  1.) setup func with parameter (textField: UITextField) with return true
        //  2.) link the text field with the delegate
    }
    
    
    /**
        Loading a webpage in background downloading
     */
    func loadWebSite() {
        let urlAddress = urlTextField.text!
        let queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)
        if urlAddress != "" {
            dispatch_async(queue, {
                if let link = NSURL(string: urlAddress) {
                    let request = NSURLRequest(URL: link)
                    print("Start to loading a webpage...")
                    //                    (webViewDidFinishLoad(self.webView))
                    //                    self.webViewDidFinishLoad(self.webView)
                    let mainQueue = dispatch_get_main_queue()
                    dispatch_async(mainQueue, {         // if download an image is finish, then back to the front queue and display the image
                        self.webView.loadRequest(request)
                        //                         var a = webView.loading    //tester
                    })
                } else {
                    print("Could not load the webpage")
                }
            })
        }
    }
    
    /**
        Call back when the webpage is starting to load
        - parameter webView: self WebView
     */
    func webViewDidStartLoad(webView: UIWebView) {
//        print("Web downloading is starting!!!")
        wvcActivityIndicator.startAnimating()
        
    }
    
    /**
        call back when the webpage is loaded
        - parameter webView: self WebView
     */
    func webViewDidFinishLoad(webView: UIWebView) {
//        print("Web downloading is done!!!")
        wvcActivityIndicator.stopAnimating()
    }
    
}
