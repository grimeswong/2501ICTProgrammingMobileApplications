//
//  FullViewController.swift
//  Friends
//
//  Created by Grimes Wong on 24/05/2016.
//  Copyright © 2016 Grimes Wong s2193948. All rights reserved.
//
//  Show the collection of Photos of Flickr (Social Media Account)

import UIKit

protocol FullViewControllerDelegate {
    func previousItemFor(viewController: FullViewController)
    func nextItemFor(viewController: FullViewController)
    func deleteCurrentPhoto(deleteRow: Int, viewController: FullViewController)
}

class FullViewController: UIViewController {
    
    var fullViewDelegate: FullViewControllerDelegate!
    var fvcImageData = NSData(contentsOfFile: "")
    var fvcPhotoIndex : Int = 0
    
    @IBOutlet weak var fullView: UIImageView!
    
    //MARK: Main View
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        fullView.image = UIImage(data: (fvcImageData)!) ?? UIImage (named: "nIA")
        print("FVC: fvcIndexPath = \(fvcPhotoIndex)")
    }
    
    /**
        Function for Deleting current photo
     */
    @IBAction func deletePhotoButton(sender: AnyObject) {
        print("delete button pressed")
        let alertTitle = "this photo"
//            alertTitle = dvcPhoto!.title
        
        //  1.)Setup UIAlertController
        let deleteAlert = UIAlertController(title: "Confirm Delete", message: "Do you want to delete \(alertTitle) logo", preferredStyle: .ActionSheet)
        //  2.)Setup UIAlertAction
        let deleteAction = UIAlertAction(title: "Delete", style: .Destructive, handler: { alertAction in
            //            print("\(alertAction.title) was pressed")
            //  1.) delete action (pass current photo data to remove such as indexPath
            self.fullViewDelegate?.deleteCurrentPhoto(self.fvcPhotoIndex, viewController: self)            //  2.) dismiss current viewcontroller and navigate back to the CollectionView Controller
            self.navigationController?.popViewControllerAnimated(true)
//            self.navigationController?.popToRootViewControllerAnimated(true)    // pop the to root view controller
        })
        let cancelAction = UIAlertAction(title: "Cancel", style: .Cancel, handler: nil)
        //  3.)Add alertaction to alertController
        deleteAlert.addAction(deleteAction)
        deleteAlert.addAction(cancelAction)
        //  4.)present alert viewController
        presentViewController(deleteAlert, animated: true, completion: nil)
    }
    
    // MARK: - Navigation
    /**
        The action to swipe left
     */
    @IBAction func swipedLeft(sender: AnyObject) {
        fullViewDelegate.nextItemFor(self)
        print("swipeLeft")
    }
    
    /**
        The action to swipe Right
     */
    @IBAction func swipedRight(sender: AnyObject) {
        fullViewDelegate.previousItemFor(self)
        print("swipeRight")
    }
    @IBAction func tapAction(sender: AnyObject) {
        print("tapped")
    }
   

}
