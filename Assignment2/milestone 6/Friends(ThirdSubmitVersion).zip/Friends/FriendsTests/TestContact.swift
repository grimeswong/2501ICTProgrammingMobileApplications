//
//  TestContact.swift
//  Friends
//
//  Created by Grimes Wong on 20/05/2016.
//  Copyright © 2016 Grimes Wong s2193948. All rights reserved.
//
//

import XCTest
@testable import Friends

class TestContact: XCTestCase {

    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }

    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measureBlock {
            // Put the code you want to measure the time of here.
        }
    }
    
    // MARK: Contact Tests
    
    /**
     Setup a properlist of file for storing photo details
     - Returns: a file name where the object is saving to
     */
    func setupPropertylist() -> String {
        let path = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask,true).first! as NSString
        let file = path.stringByAppendingPathComponent("Friends.plist") // the path for store the "Photos.plist"
        return file
    }
    
    ///
    /// Test Samples
    ///
    //    let testFirstName = "Forest"
    //    let testLastName = "Gum"
    //    let testAddress = "Run..., don't stay on the street at midnight"
    //    let testImageURL = NSURL(string: "http://www.studyinaus.com/wp-content/uploads/2014/02/logo2.gif")
    //    let testNAvailable = UIImage(named: "nIA")
    
    ///
    /// Test all Empty input
    ///
    func testAllEmptyAndNilInput() {
        let testFirstName = ""
        let testLastName = ""
        let testAddress = ""
        let testImageURL = ""
        let testSMAccount = [SMAccount(id: "", type:"")]
        let testContact = Contact(firstName: testFirstName, lastName: testLastName, address: testAddress, imageURL: testImageURL, sMAccount: testSMAccount)
        
        XCTAssertEqual(testContact.firstName, testFirstName)
        XCTAssertEqual(testContact.lastName, testLastName)
        XCTAssertEqual(testContact.address, testAddress)
        XCTAssertEqual(testContact.imageURL, testImageURL)
        XCTAssertEqual(testContact.sMAccount?[0], testSMAccount[0])
    }
    
    
    ///
    /// Test the title name, tags and uRL in normal correct input scenarios
    ///
    func testNameAndAddressInput() {
        let testFirstName = "Forrest"
        let testLastName = "Gump"
        let testAddress = "Run..., don't stay on the street at midnight"
        let testContact = Contact(firstName: testFirstName, lastName: testLastName, address: testAddress)
        
        XCTAssertEqual(testContact.firstName, testFirstName)
        XCTAssertEqual(testContact.lastName, testLastName)
        XCTAssertEqual(testContact.address, testAddress)
        
    }
    
    ///
    /// Test Setter and Getter include SMAccount and TLEntry
    ///
    func testSettersAndGetters() {
        let testFirstName1 = "Anne", testFirstName2 = "David"
        let testLastName1 = "Billington", testLastName2 = "Topor"
        let testAddress1 = "Ellis", testAddress2 = "William"
        let testImageURL1 = "a", testImageURL2 = "b"
        let testTLEntrys1 = TLEntry(siteData:"123", album:"456")
        let testTLEntrys2 = TLEntry(siteData:"ABC", album:"DEF")
        let testSMAccounts1 = [SMAccount(id:"a", type:"b", tlEntry: testTLEntrys1), SMAccount(id:"c", type:"d", tlEntry:testTLEntrys2)]
        let testSMAccounts2 = [SMAccount(id:"e", type:"f", tlEntry: testTLEntrys1), SMAccount(id:"g", type:"h", tlEntry: testTLEntrys2)]
        
        
        var contact : [Contact] = [] // empty array
        
        contact.append(Contact(firstName: "", lastName: "", address: "", imageURL: nil, imageData: nil, sMAccount: nil))
        
        contact[0].firstName = testFirstName1
        contact[0].lastName = testLastName1
        contact[0].address = testAddress1
        contact[0].imageURL = testImageURL1
        contact[0].sMAccount = testSMAccounts1
        
        XCTAssertEqual(contact[0].firstName, testFirstName1)
        XCTAssertEqual(contact[0].lastName, testLastName1)
        XCTAssertEqual(contact[0].address, testAddress1)
        XCTAssertEqual(contact[0].imageURL, testImageURL1)
        XCTAssertEqual(contact[0].imageData, nil)
        XCTAssertEqual(contact[0].sMAccount?[0].smaID, testSMAccounts1[0].smaID)        // Test the SMAccount first item smaID
        XCTAssertEqual(contact[0].sMAccount?[0].smaType, testSMAccounts1[0].smaType)    // Test the SMAccount first item smaTYPE
        XCTAssertEqual(contact[0].sMAccount?[0].tlEntry?.siteData, testSMAccounts1[0].tlEntry?.siteData)    //test TLEntry.siteData
        XCTAssertEqual(contact[0].sMAccount?[0].tlEntry?.album, testSMAccounts1[0].tlEntry?.album)
        
        XCTAssertEqual(contact[0].sMAccount?[1].smaID, testSMAccounts1[1].smaID)    // Test the SMAccount second item smaID
        XCTAssertEqual(contact[0].sMAccount?[1].smaType, testSMAccounts1[1].smaType)
        XCTAssertEqual(contact[0].sMAccount?[1].tlEntry?.siteData, testSMAccounts1[1].tlEntry?.siteData)
        XCTAssertEqual(contact[0].sMAccount?[1].tlEntry?.album, testSMAccounts1[1].tlEntry?.album)
        
        /* replace the data in the same position of array */
        contact[0].firstName = testFirstName2
        contact[0].lastName = testLastName2
        contact[0].address = testAddress2
        contact[0].imageURL = testImageURL2
        contact[0].sMAccount = testSMAccounts2
        
        XCTAssertEqual(contact[0].firstName, testFirstName2)
        XCTAssertEqual(contact[0].lastName, testLastName2)
        XCTAssertEqual(contact[0].address, testAddress2)
        XCTAssertEqual(contact[0].imageURL, testImageURL2)
        XCTAssertEqual(contact[0].imageData, nil)
        XCTAssertEqual(contact[0].sMAccount?[0].smaID, testSMAccounts2[0].smaID)    // Test the SMAccount first item smaID
        XCTAssertEqual(contact[0].sMAccount?[0].smaType, testSMAccounts2[0].smaType)
        XCTAssertEqual(contact[0].sMAccount?[0].tlEntry?.siteData, testSMAccounts2[0].tlEntry?.siteData)
        XCTAssertEqual(contact[0].sMAccount?[0].tlEntry?.album, testSMAccounts2[0].tlEntry?.album)
        
        
        XCTAssertEqual(contact[0].sMAccount?[1].smaID, testSMAccounts2[1].smaID)    // Test the SMAccount second item smaID
        XCTAssertEqual(contact[0].sMAccount?[1].smaType, testSMAccounts2[1].smaType)
        XCTAssertEqual(contact[0].sMAccount?[1].tlEntry?.siteData, testSMAccounts2[1].tlEntry?.siteData) //Test the TLEntry
        XCTAssertEqual(contact[0].sMAccount?[1].tlEntry?.album, testSMAccounts2[1].tlEntry?.album)

        
        /*
        for first in testFirstNames {
            contact.firstName = first
            
            for last in testLastNames {
                contact.lastName = last
                
                for address in testAddress {
                    contact.address = address
                    
                    for imageURL in testImageURL {
                        contact.imageURL = imageURL
                        
                        XCTAssertEqual(contact.firstName, first)
                        print(contact.firstName)
                        XCTAssertEqual(contact.lastName, last)
                        XCTAssertEqual(contact.address, address)
                        XCTAssertEqual(contact.imageURL, imageURL)
                        
                        for smaAccount in testSMAccount {
                                contact.sMAccount = smaAccount
                                print(contact.sMAccount?.count)

                            
                            
                             //   XCTAssertEqual(contact.sMAccount?[0].smaID, smaAccount.smaID)
                             //   XCTAssertEqual(contact.sMAccount?[0].smaType, smaAccount.smaType)
                            
                        }
                    }
                }
            }
        }
        */
    }


} //Test end tag
