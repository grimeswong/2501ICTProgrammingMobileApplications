//
//  CollectionViewController.swift
//  Friends
//
//  Created by Grimes Wong on 24/05/2016.
//  Copyright © 2016 Grimes Wong s2193948. All rights reserved.
//
//  Purpose: Show the Personal Photo Album

import UIKit

protocol CollectionViewControllerDelegate {
    
    func saveCVCTLEntry(cvcTLEntry: TLEntry, viewcontroller: CollectionViewController)
}

class CollectionViewController: UICollectionViewController, PhotoDetailViewControllerDelegate, FullViewControllerDelegate {
    
    // MARK: Properties
    
    var cvcTLEntry : TLEntry? = nil
    var cvcImageData: [NSData]? = nil
    var cvcsiteData: String = ""
    var cvcAlbum: String = ""
    var cvcID: String = ""
    var cvcCurrentIndexPath = NSIndexPath()
    var cvcDelegate : CollectionViewControllerDelegate? = nil
    
    // MARK: Main View
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //self.navigationItem.title = cvcAlbum    //Load the album name from the property
        self.navigationItem.title = "Flickr Photos"
        
        /*only load once below unless user back to the detail view*/
//        cvcID = "strictfunctor" //tester
        
        /* flickr */
        FlickrAPIKey = "cb53fc85826cceb68025a77e4fa5a18a"
        let user = cvcID
        let photos = photosForUser(user)
        
        if photos != nil {
            for photo in photos! {  //download photo in background
                //for photo in photosArray.count {
                let queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0)
                dispatch_async(queue, {
                    let photoURLString = urlString(photo, format: .Small)
                    let url = NSURL(string: photoURLString!)
                    let photoData = NSData(contentsOfURL: url!)
                    let mainQueue = dispatch_get_main_queue()
                    dispatch_async(mainQueue, {         // if download an image is finish, then back to the front queue and display the image
                        self.cvcTLEntry?.imagesData?.append((photoData)!)
                        print("CVC cvcTLEntry?.imagesData now is = \(self.cvcTLEntry?.imagesData?.count)")
                        self.collectionView?.reloadData()
                    })
                })
            
            self.collectionView!.reloadData()
                
            }
        } else {
            print("Could not download photos!!!")
        }
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        
        //1) load images if cvcTLEntry exist
        //2) reload data
        
        if cvcTLEntry != nil {  //load TLEntry album images
            print("CVC: cvcTLEntry != nil, \(cvcTLEntry)")
            print("CVC: cvcImageData.count = \(cvcTLEntry?.imagesData?.count)")
            cvcImageData = cvcTLEntry?.imagesData
            
        } else {    //create TLEntry
            cvcTLEntry = TLEntry(imagesData: [], siteData: "", album: "")
            print("CVC: cvcTLEntry == nil, creating TLEntry")
            print("CVC: cvcImageData.count = \(cvcTLEntry?.imagesData?.count)")
        }
        
        self.collectionView!.reloadData()       //reload images
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(true)
        cvcTLEntry?.album = cvcAlbum ///????
        self.cvcDelegate?.saveCVCTLEntry(cvcTLEntry!, viewcontroller: self) // Save all the TLEntry photos back
    }
    
    //MARK: Segue
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "showPhoto" {
            let fvc = segue.destinationViewController as! FullViewController
            fvc.fullViewDelegate = self    // very important
            let indexPaths = self.collectionView!.indexPathsForSelectedItems()  //mutli selected
            let indexPath = indexPaths![0] as NSIndexPath                       //single select
              fvc.fvcImageData = cvcTLEntry?.imagesData?[indexPath.row]
            cvcCurrentIndexPath = indexPath    //save the current index path to global var
            fvc.fvcPhotoIndex = indexPath.row
            print("CVC: cvcCurrentIndexPath = \(cvcCurrentIndexPath)")
            
        } else if segue.identifier == "addPhoto" {
            let pvc = segue.destinationViewController as! PhotoDetailViewController
            pvc.pvcDelegate = self  //very important
        }
        
    }   //Segue tag end
    
    // MARK: Collection View
    
    // First, set the number of sections
    /**
        Counting the number of items in Photolist to show
     */
    override func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if let validTLEntry = cvcTLEntry?.imagesData {
            return (validTLEntry.count)
        } else {
            return 0
        }
        
    }
    
    // Second, set the cell
    /**
        Setup the cells by the datasource of Photo modal
     */
    override func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) ->UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier("photoCell", forIndexPath: indexPath) as! CollectionViewCell
        cell.cellImage.image = UIImage(data: (cvcTLEntry?.imagesData?[indexPath.row])!)
//        self.collectionView?.reloadData()
        return cell
    }
    
    // MARK: PDVC Delegate
    
    /**
        Queue the image downloading in background, then show the image
        - parameter urlString: URL address
        - parameter viewController: URL PhotoDetailViewController
     */
    func dvcBackgroundDownload(urlString: String, viewController: PhotoDetailViewController) {
        let url = NSURL(string: urlString)
        let queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0)
        
        dispatch_async(queue, {
            if let data = NSData(contentsOfURL: url!), // download some binary data, allow specific attempt to download the data
                let image = UIImage(data: data) {        // get the image from data
                print("CVC for PVC: pvcImageDownloading")
                
                let mainQueue = dispatch_get_main_queue()
                dispatch_async(mainQueue, {         // if download an image is finish, then back to the front queue and display the image
                    viewController.pvcImagePreview.image = image
                    viewController.pvcImageData = UIImagePNGRepresentation(image)
                })
            } else {
                viewController.pvcImagePreview.image = UIImage(named: "noImageAvailable")
                print("Could not download image for = \(urlString)")
            }
        })
    }
    
    /**
        Process to save photo in the image preview
     */
    func savePhoto(pvcImageData: NSData, viewController: PhotoDetailViewController) {
        cvcTLEntry?.imagesData?.append(pvcImageData)
        print("CVC: func savePhoto...")
        print("CVC: cvcTLEntry?.imageData?.count = \(cvcTLEntry?.imagesData?.count)")
    }
    
    // MARK: FVC Delegate
    
    
    /**
        Delete the Fullview controller current photo
     */
    func deleteCurrentPhoto(deleteRow: Int, viewController: FullViewController) {
//        print("CVC: deleteFunt = \(cvcTLEntry?.imagesData![deleteRow])")
        cvcTLEntry?.imagesData!.removeAtIndex(deleteRow)
    }
    
    /**
     Show the previous image if swipe right in Full View controller
     - parameter fullViewController: the view controller to show an image in full screen
     */
    func previousItemFor(fullViewController: FullViewController) {
        let row = cvcCurrentIndexPath.row
        let previousRow: Int
        if row == 0 { previousRow = (cvcTLEntry?.imagesData?.count)! - 1 } // stop the swipe back if index is 0
        else {previousRow = row - 1}    //index - current index - 1 (reach the last element of the array (loop back)
        let indexPath = NSIndexPath(forRow: previousRow, inSection: cvcCurrentIndexPath.section)
        cvcCurrentIndexPath = indexPath
        
        fullViewController.fvcImageData = (cvcTLEntry?.imagesData![previousRow])    //pass the object to Full view

        fullViewController.fullView.image = UIImage(data: (cvcTLEntry?.imagesData![previousRow])!) //show current image to the Full view
        
    }
    
    /**
     Show the next image if swipe left in Full View controller
     - parameter fullViewController: the view controller to show an image in full screen
     */
    func nextItemFor(fullViewController: FullViewController) {
//        let row = cvcCurrentIndexPath.row
//        let nextRow: Int
//        if row == (cvcTLEntry?.imagesData?)!.count - 1 { nextRow = 0 }
//        else {nextRow = row + 1}
//        let indexPath = NSIndexPath(forRow: nextRow, inSection: cvcCurrentIndexPath.section)
//        cvcCurrentIndexPath = indexPath
//        fullViewController.fvcimagesData = (cvcTLEntry?.imagesData[nextRow]!
//        print("masterEntries[nextRow] = \(masterEntries[nextRow])")
//        print("fvcView currentPhoto = \(fullViewController.fvcPhoto!)")
//        print(masterEntries[nextRow].uRL)
//        //        fullViewController.fvcImage = imageCachingLoad(masterEntries[nextRow].uRL)
//        fullViewController.fvcFullView.image = imageCachingLoad(masterEntries[nextRow].uRL) //show current image to the Full view
//        print("URL is \(masterEntries[nextRow].uRL)")
    }

}
