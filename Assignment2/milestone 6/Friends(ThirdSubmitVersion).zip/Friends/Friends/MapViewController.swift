//
//  MapViewController.swift
//  Friends
//
//  Created by Grimes Wong on 22/05/2016.
//  Copyright © 2016 Grimes Wong s2193948. All rights reserved.
//
//  Purpose: This view controller show the map of the user's address

import UIKit
import MapKit
import CoreLocation

protocol MapViewControllerDelegate {
    func saveAddress(contactAddress: String, viewController: MapViewController)
}

class MapViewController: UIViewController, CLLocationManagerDelegate {
    
    //var mvcContact: Contact? = nil       //The current Contact object
    var mvcAddress: String = ""          //The current Contact address
    var mvcDelegate: MapViewControllerDelegate? = nil   //DVC delegate
    let locationManager = CLLocationManager()
    
    @IBOutlet weak var addressTextField: UITextField!
    @IBOutlet weak var addressMapView: MKMapView!
    
    // MARK: Main Views Functions
    
    override func viewDidAppear(animated: Bool) {
//        locationManager.startUpdatingLocation() //set up to update the location
//        locationManager.delegate = self
        
        addressTextField.text = mvcAddress      //display the address text
        showMap()
    }

    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(true)
        mvcAddress = addressTextField.text!
        self.mvcDelegate?.saveAddress(mvcAddress, viewController: self)
        //mvcContact?.address = addressTextField.text!
        //self.mvcDelegate?.saveAddress(mvcContact!, viewController: self)
    }
    
    // MARK: Functions
    
    /**
        Dismiss the softkeyboard when user's done the typing. Also search the address and show on the map after user type a valid address
     */
    func textFieldShouldReturn(textField: UITextField) -> Bool { // called when 'return' key pressed. return NO to ignore.
        let addressString = addressTextField.text!
//        mvcContact?.address = addressString
        mvcAddress = addressString
        textField.resignFirstResponder()    // disappear keyboard (This textField argument can be include all the text field in the same view controller
        //self.mvcDelegate?.dvcBackgroundDownload(urlString!, viewController: self)
        showMap()
        
        return true
    }
    
    /**
        This function show the map if user type a valid address, a placemark will be shown on the map. If an address is not valid, the alert window will show up for notify user
     */
    func showMap() {
        var showAddress = CLLocationCoordinate2D(latitude: -27, longitude: 153) //default initialize (Brisbane Region)
        let geocoder = CLGeocoder()     // This convert the address to longtitude and latitude
        geocoder.geocodeAddressString(mvcAddress, completionHandler: {(placemarks, error) -> Void in
            if((error)) != nil {
                print("Error", error)
                
                // create the alert
                let NoResultAlert = UIAlertController(title: "No Match Result", message: "Could not found a result, please retype address in detail for getting better result", preferredStyle: UIAlertControllerStyle.Alert)
                // add an action (button)
                let okAction = UIAlertAction(title: "OK", style: .Default, handler: nil)
                NoResultAlert.addAction(okAction)
                self.presentViewController(NoResultAlert, animated: true, completion: nil)
            }
            
            if let placemark = placemarks?.first {  //use the first result of the search results
                let coordinates : CLLocationCoordinate2D = placemark.location!.coordinate
                showAddress = coordinates
                print("coordinates is \(coordinates)")
                let annotation = MKPlacemark(placemark: placemark)
                self.addressMapView.addAnnotation(annotation)
                let span = MKCoordinateSpanMake(0.02, 0.02) //zoom scale: smaller number zoom in
                let brisbaneRegion = MKCoordinateRegion(center: showAddress, span: span)
                self.addressMapView.setRegion(brisbaneRegion, animated: true)
                //self.addressMapView.setUserTrackingMode(.Follow, animated: true) // set GPS tracking that follow the user location
                //locationManager.requestAlwaysAuthorization() // always run even in background (user use other apps)
                self.locationManager.requestWhenInUseAuthorization() // run only when the app is in use
            }
        })
        //print(showAddress)
    }
    
    /**
        For allow the app to tracking user location after confirm to authorise
     */
    func locationManager(manager: CLLocationManager, didChangeAuthorizationStatus status: CLAuthorizationStatus) {    // to ask user to give the authorization to use the tracking user location
        
        let allowed: Bool
        
        switch status {
            
        // User has not yet made a choice with regards to this application
        case .NotDetermined:
            allowed = false
            print("not determined yet")
            
            // This application is not authorized to use location services.  Due
            // to active restrictions on location services, the user cannot change
        // this status, and may not have personally denied authorization
        case .Restricted:
            allowed = false
            print("restricted")
            
            // User has explicitly denied authorization for this application, or
        // location services are disabled in Settings.
        case .Denied:
            allowed = false
            print("User denied using location")
            
            // User has granted authorization to use their location at any time,
        // including monitoring for regions, visits, or significant location changes.
        case .AuthorizedAlways:
            allowed = true
            print("Even works in the background")
            
            // User has granted authorization to use their location only when your app
            // is visible to them (it will be made visible to them if you continue to
            // receive location updates while in the background).  Authorization to use
        // launch APIs has not been granted.
        case .AuthorizedWhenInUse:
            allowed = true
            print("Allowed when in use")
        }
        
        if allowed {
            locationManager.startUpdatingLocation()
        }
        
    }
    
}
