//
//  ViewController.swift
//  WebViewer
//
//  Created by Grimes Wong on 8/05/2016.
//  Copyright © 2016 Grimes Wong s2193948. All rights reserved.
//  Purpose: the web view show up a web page if enter a valid URL address
//
//  1.) Setup textfield and make the function for resign keyboard
//  2.) Must setup transport security  
//  3.) In Info.plist, add an App Transport Security Setting - > add AllowArbitraryLoads -> set Yes
//  2016-05-08 23:16:49.104 WebViewer[14617:745603] App Transport Security has blocked a cleartext HTTP (http://) resource  load since it is insecure. Temporary exceptions can be configured via your app's Info.plist file.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var webView: UIWebView!
    @IBOutlet weak var urlTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /**
        This function can display a web page after enter a valid URL address
        - parameter textField: URL textfield
        - returns: true
     */
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()    //press the return button
        let urlAddress = urlTextField.text!
        if urlAddress != "" {
            let link = NSURL(string: urlAddress)
            let request = NSURLRequest(URL: link!)
            webView.loadRequest(request)
            
        }
        return true
        //  Setup for resign the keyboard when press the "return button"
        //  1.) setup func with parameter (textField: UITextField) with return true
        //  2.) link the text field with the delegate
    }

}

