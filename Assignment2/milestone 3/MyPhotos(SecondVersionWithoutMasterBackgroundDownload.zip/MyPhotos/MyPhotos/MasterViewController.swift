//
//  ViewController.swift
//  MyPhotos
//
//  Created by s2193948 on 8/04/2016.
//  Copyright © 2016 s2193948. All rights reserved.
//  Purpose: This class is the collection view that list out all the images, and can modify exisiting photos' details or adding a new image

import UIKit

class MasterViewController: UICollectionViewController, DetailViewControllerDelegate {
    
    // MARK: Properties
    
    var masterEntries = PhotoList().entries     //a list to store the images
    var currentImageIndex : Int? = nil          //save the photo object index which using by masterview controller
    var currentPhoto: Photo? = nil              //the current Photo object
    //var validated: Bool = false               //uncomment not useful property
    
    
    // MARK: Main UI Functions
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //  load exisiting property list
        let array = NSMutableArray(contentsOfFile: setupPropertylist())
        if array != nil{
//            print("array = \(array)")
            print("array.count = \(array!.count)")
            print("plist is exsiting")
            print("plist path is = \(setupPropertylist())")
            //  load plist
//            let object = array![0]
//            let title = object["title"] as! NSString
//            let tags = object["tags"] as! NSArray
//            let uRL = object["uRL"] as! NSString
            for element in array! {
                let changeToNormatString = changeType(element)
                masterEntries.append(Photo(title: changeToNormatString.0, tags: changeToNormatString.1, uRL: changeToNormatString.2))
            }
            self.collectionView!.reloadData()
    
        }else{
            print("plist is nil")
            //  create plist? set three samples into property list
            let newPhoto = Photo(title: "Sample 1 Griffith", tags: ["Nathan", "University"], uRL: "http://www.acsfoundation.com.au/bdi/assets/img/logos/Griffith3.png")
            let newPhoto2 = Photo(title: "Sample 2 UQ", tags: ["St Lucia", "Brisbane"], uRL: "http://www.uq.edu.au/international/images/banners/UQlogoC-colour-M.jpg")
            let newPhoto3 = Photo(title: "QUT", tags: ["QUT", "Yeah"], uRL: "http://acems.org.au/acems_wp/wp-content/uploads/2015/09/QUT_Logo_2Lines_CMYK.jpg")
            let pl = propertyListRepresentation(newPhoto)
            let pl2 = propertyListRepresentation(newPhoto2)
            let pl3 = propertyListRepresentation(newPhoto3)
            let arrayNew : NSMutableArray = []   //create an array
            arrayNew.addObject(pl)
            arrayNew.addObject(pl2)
            arrayNew.addObject(pl3)
            arrayNew.writeToFile(setupPropertylist(), atomically: true)      //write data to propertyList
            //  load plist out to
            for element in arrayNew {
                let changeToNormalString = changeType(element)
                masterEntries.append(Photo(title: changeToNormalString.0, tags: changeToNormalString.1, uRL: changeToNormalString.2))
            }
            self.collectionView!.reloadData()
        }
//        For reference only as below (Author use only)
//        let linkURL = NSURL(string: masterEntries[0].uRL!)
//        let data = NSData(contentsOfURL: linkURL!)
//        let image = UIImage(data: data!)
    
    /*  for foto in photolist {
        loadPhotoInBackground(photo: foto) // load the function which download an image in background (Multithread)
        }
    */
    
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        self.collectionView!.reloadData()       //reload images
        /* Photo list counters */
        let currentArray = NSMutableArray(contentsOfFile: setupPropertylist())
        print("masterEntries.count = \(masterEntries.count) in viewWillAppear")
        print("CurrentArray.count in plist = \(currentArray!.count) in viewWillAppear")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: PrepareForSegue
    /**
        Show selected image by segue or adding a new photo details
    */
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "ShowImage" {
            //print("Segue = ShowImage")    //tester//
            let dvc = segue.destinationViewController as! DetailViewController
            //print(dvc)    //tester//
            let indexPaths = self.collectionView!.indexPathsForSelectedItems()  //mutli selected
            //print(indexPaths) //tester//
            let indexPath = indexPaths![0] as NSIndexPath                       //single select
            //tester print("index Path = \(indexPath.row)")  //tester//
            
            
            let tempLink = masterEntries[indexPath.row].uRL
            if tempLink != "" {                                 //Double confirm the url whether is an empty string
                let link = NSURL(string: tempLink)
                if let data = NSData(contentsOfURL: link!) {
                    if let image = UIImage(data: data) {
                        dvc.currentImage = image
                    }
                }else{
                    dvc.currentImage = UIImage(named:"imageNotAvailable")
                }
                currentPhoto = masterEntries[indexPath.row] // refer the existing object
                currentImageIndex = indexPath.row //save current object index
                dvc.photoDVC = masterEntries[indexPath.row] // original is currentPhoto
                dvc.dvcDelegate = self
            } else {
                dvc.currentImage = UIImage(named:"imageNotAvailable")
               print("nothing in tempLink")
            }
        } else if segue.identifier == "AddImage" {
            print("Segue = AddImage")
            let dvc = segue.destinationViewController as! DetailViewController
            dvc.dvcDelegate = self  //very important
        }
    }
    
    // MARK: Functions
    
    /**
        Save image to the array list
        - Parameter photo: the photo object from DVC
    */
    func processPhotoDetails(photo: Photo, exisitngPhoto: Bool, delete: Bool){
        //  1) validate the Photo object link(String) is valid (empty string)
        //  2) decide the Argument is a new or exisiting photo object
        //  3) determine to save the details or not
        
        var pl = propertyListRepresentation(photo)   // Change Photo type to NSMutableDictionary
        let currentArray = NSMutableArray(contentsOfFile: setupPropertylist())            //load current plist
        
        if validateIsNotEmptyString(photo) == true && delete != true{   // confirm is link is validated
            print("validated Photo")
            print("photolink is \(photo.uRL)")
            if exisitngPhoto == true {    // is a existing object
                masterEntries[currentImageIndex!] = photo
                
                pl = propertyListRepresentation(photo)
                currentArray!.replaceObjectAtIndex(currentImageIndex!, withObject: pl)    //replace Object
                currentArray!.writeToFile(setupPropertylist(), atomically: true)
                
                print("Save exsting Photo object")
            } else {          //is a new object
                masterEntries.append(photo)
    
                pl = propertyListRepresentation(photo)   //pl is NSDictionar
        
                currentArray!.addObject(pl)                                               //add object
                currentArray!.writeToFile(setupPropertylist(), atomically: true)
                print("Save a new Photo object")
                
            }
        } else if delete == true {
            masterEntries.removeAtIndex(currentImageIndex!)
            let currentArray = NSMutableArray(contentsOfFile: setupPropertylist())
            currentArray!.removeObjectAtIndex(currentImageIndex!)
            currentArray!.writeToFile(setupPropertylist(), atomically: true)
            
        } else {
            print("Photo.url is an empty string, not going to save this object")
        }
        print("masterEntries now is = \(masterEntries.count)")
        currentImageIndex = nil
        currentPhoto = nil
    }
    
    /**
        Validate the photo's URL that is not an emtpy string
        - Parameter photo: the Photo object passed from DetailViewController
        - Returns: true if confirmed URL is not an empty string
    */
    func validateIsNotEmptyString (photo: Photo) -> Bool{
        print("validating photo \(photo.uRL)")
        if photo.uRL != "" {
            print("validate photo.uRL is not an empty string")
            return true
        }else{
            print("photo.uRL is an empty string")
            return false
        }
    }
    
    /**
         Setup a properlist of file for storing photo details
         - Returns: a file name where saving the photo details
     */
    func setupPropertylist() -> String {
        let path = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask,true).first! as NSString
        let file = path.stringByAppendingPathComponent("Photos.plist") // the path for store the "Photos.plist"
        return file
    }
    
    /**
        Change the Photo details into type of NSMutableDictionary
        - Returns: a Dictionary to store the title, tags and URL
     */
    func propertyListRepresentation(photo: Photo) -> NSMutableDictionary {
        let title = photo.title
        let tags  = photo.tags
        let uRL = photo.uRL
        return ["title": title,"tags": tags, "uRL": uRL]
    }
    
    /**
        Change the Object to the proper string type
     */
    func changeType(object: AnyObject) -> (String, [String], String){
            let title = object["title"] as! NSString
            let tags = object["tags"] as! NSArray
            let uRL = object["uRL"] as! NSString
            let realTitle = title as String
            let realTags = tags as! [String]
            let realURL = uRL as String
            return (realTitle,realTags,realURL)
    }
    
    // MARK: CollectionView
    // First, set the number of sections
    /**
        Counting the number of items in Photolist to show
    */
    override func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return masterEntries.count
    }
    
    // Second, set the cell
    /**
        Setup the cells by the datasource of Photo modal
    */
    override func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) ->UICollectionViewCell {
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier("photoCell", forIndexPath: indexPath) as! CollectionViewCell
        let tempLink = masterEntries[indexPath.row].uRL
            let link = NSURL(string: tempLink)
            if let data = NSData(contentsOfURL: link!) {
                if let currentPhoto = UIImage(data: data){
                cell.cellImage.image = currentPhoto     //image is the property of UIImageView
                }
            }else{
                cell.cellImage.image = UIImage(named: "imageNotAvailable")
        }
        return cell
    }
    
    
    /*
        Queue the image download in background, then reload the photolist
        - Parameter Photo: the image that need to download
    */
    
    
    
  /*  func loadPhotoInBackground (photo: Photo) {
        
        let queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0)
        
        let backgroundDownload = {      //Closure
            
  //         if let data = NSData(contentsOfURL: NSURL(string: photo.urL)!) {
            if let data = NSData(contentsOfURL: NSURL(string: photo.uRL!)!) {
                let mainQueue = dispatch_get_main_queue()
                dispatch_async(mainQueue, {
                    //photo.imageData = data  // need a method change the NSData back to link // for store image in a Photo list
                    
                    self.collectionView!.reloadData()       //reload image after downloaded
               })
            }else{
                print("Could not download image '\(photo.urlStr)'")
            }
        }
        
        dispatch_async(queue, backgroundDownload)
    }
    
   */
    
}   // class end

