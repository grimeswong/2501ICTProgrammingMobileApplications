//
//  MyPhotosListTests.swift
//  MyPhotos
//
//  Created by Grimes Wong on 18/04/2016.
//  Copyright © 2016 s2193948. All rights reserved.
//

import XCTest
@testable import MyPhotos

class MyPhotosListTests: XCTestCase {

    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }

    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measureBlock {
            // Put the code you want to measure the time of here.
        }
    }
    
    // Mark: Tests
    
    ///
    /// Test the empty PhotoList and make sure its element is empty
    ///
    func testEmptyPhotoList(){
        let testList = PhotoList()
        XCTAssertEqual(testList.entries.count, 0)
    }
    
    ///
    /// Test the Photo object can be added to PhotoList class
    ///
    func testAddingPhotoToPhotoList(){
        let testList = PhotoList()
        let entry = Photo(title: "Grifith", tags: ["G","U"], uRL: "http://www.grifiith.edu.au")
        testList.entries.append(entry)
        XCTAssertEqual(testList.entries.count, 1)
        XCTAssertTrue(testList.entries[0] === entry)    //confirm pointing to the same reference
    }
    
    ///
    /// Test the Photo can be inserted in middle of the PhotoList
    ///
    func testInsertPhotoToPhotoList(){
        let testList = PhotoList()
        let entry1 = Photo(title: "Grifith", tags: ["G","U"], uRL: "http://www.grifiith.edu.au")
        testList.entries.append(entry1)
        XCTAssertEqual(testList.entries.count, 1)
        XCTAssertTrue(testList.entries[0] === entry1)    //confirm pointing to the same reference
        
        let entry2 = Photo(title: "QUT", tags: ["Q","U","T"], uRL: "http://www.qut.edu.au")
        testList.entries.insert(entry2, atIndex: 0)
        XCTAssertEqual(testList.entries.count, 2)
        XCTAssertTrue(testList.entries[0] === entry2)
        XCTAssertTrue(testList.entries[1] === entry1)
        
        //insert in the middle of the list
        let entry3 = Photo(title: "UQ", tags: ["U","Q"], uRL: "http://www.uq.edu.au")
        testList.entries.insert(entry3, atIndex: 1)
        XCTAssertEqual(testList.entries.count, 3)
        XCTAssertTrue(testList.entries[0] === entry2)
        XCTAssertTrue(testList.entries[1] === entry3)
        XCTAssertTrue(testList.entries[2] === entry1)
        
    }
    
    ///
    /// Test the Photo can be removed from the PhotoList
    ///
    func testRemovePhotoFromPhotoList(){
        let testList = PhotoList()
        let entry1 = Photo(title: "Grifith", tags: ["G","U"], uRL: "http://www.grifiith.edu.au")
        testList.entries.append(entry1)
        XCTAssertEqual(testList.entries.count, 1)
        XCTAssertTrue(testList.entries[0] === entry1)    //confirm pointing to the same reference
        
        let entry2 = Photo(title: "QUT", tags: ["Q","U","T"], uRL: "http://www.qut.edu.au")
        testList.entries.insert(entry2, atIndex: 0)
        XCTAssertEqual(testList.entries.count, 2)
        XCTAssertTrue(testList.entries[0] === entry2)
        XCTAssertTrue(testList.entries[1] === entry1)
        
        //insert in the middle of the list
        let entry3 = Photo(title: "UQ", tags: ["U","Q"], uRL: "http://www.uq.edu.au")
        testList.entries.insert(entry3, atIndex: 1)
        XCTAssertEqual(testList.entries.count, 3)
        XCTAssertTrue(testList.entries[0] === entry2)
        XCTAssertTrue(testList.entries[1] === entry3)
        XCTAssertTrue(testList.entries[2] === entry1)
        
        let removedEntry2 = testList.entries.removeAtIndex(0)
        XCTAssertTrue(removedEntry2 === entry2)
        XCTAssertEqual(testList.entries.count, 2)   //  confirm after remove entry 2, the list has two items
        XCTAssertTrue(testList.entries[0] === entry3)   // confirm the position with the items is correct in the list
        XCTAssertTrue(testList.entries[1] === entry1)
        
        let removedEntry1 = testList.entries.removeAtIndex(1)
        XCTAssertTrue(removedEntry1 === entry1)
        XCTAssertEqual(testList.entries.count, 1)
        XCTAssertTrue(testList.entries[0] === entry3)
        
        let removedEntry3 = testList.entries.removeAtIndex(0)
        XCTAssertTrue(removedEntry3 === entry3)
        XCTAssertEqual(testList.entries.count, 0)
    }

    //tests end
    
    
}
