//
//  MyPhotoPListTests.swift
//  MyPhotos
//
//  Created by Grimes Wong on 29/04/2016.
//  Copyright © 2016 s2193948. All rights reserved.
//

import XCTest
@testable import MyPhotos

class MyPhotoPListTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measureBlock {
            // Put the code you want to measure the time of here.
        }
    }
    
    //  MARK: - UITest - Property list
    
    /**
     Setup a properlist of file for storing photo details
     - Returns: a file name where saving the photo details
     */
    func setupPropertylist() -> String {
        let path = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask,true).first! as NSString
        let file = path.stringByAppendingPathComponent("Photos.plist") // the path for store the "Photos.plist"
        return file
    }
    
    /**
     Change the Photo details into type of NSMutableDictionary
     - Returns: a Dictionary to store the title, tags and URL
     */
    func propertyListRepresentation(photo: Photo) -> NSMutableDictionary {
        let title = photo.title
        let tags  = photo.tags
        let uRL = photo.uRL
        return ["title": title,"tags": tags, "uRL": uRL]
    }
    
    /**
     Test the normal input in propertylist
     */
    func testPropertyListNormalInput(){
        let testTitle = "Griffith"
        let testTags = ["University", "Brisbane"]
        let testURL = "http://www.acsfoundation.com.au/bdi/assets/img/logos/Griffith3.png"
        
        let newPhoto = Photo(title: testTitle, tags: testTags, uRL: testURL)
        let pl = propertyListRepresentation(newPhoto)
        
        let arrayNS : NSMutableArray = []
        arrayNS.addObject(pl)
        arrayNS.writeToFile(setupPropertylist(), atomically: true)      //writing Photo object to property list
        let dict = NSMutableArray(contentsOfFile: setupPropertylist())         //loading Photo object from property list
        for element in dict! {                                          //
            print(element["title"])
            print(testTitle)
            XCTAssertEqual(element["title"], testTitle)
            XCTAssertEqual(element["tags"], testTags)
            XCTAssertEqual(element["uRL"], testURL)
            
            //Compare the normal Strings
            XCTAssertEqual(element["title"], "Griffith")
            XCTAssertEqual(element["tags"], ["University", "Brisbane"])
            XCTAssertEqual(element["uRL"], "http://www.acsfoundation.com.au/bdi/assets/img/logos/Griffith3.png")
        }
    }
    
    func testPropertyListEmptyInput(){
        let testTitle = ""
        let testTags = [""]        //empty array
        let testURL = ""
        let newPhoto = Photo(title: testTitle, tags: testTags , uRL: testURL)
        let pl = propertyListRepresentation(newPhoto)
        
        let arrayNS : NSMutableArray = []   //empty NSArray
        arrayNS.addObject(pl)
        arrayNS.writeToFile(setupPropertylist(), atomically: true)
        let dict = NSMutableArray(contentsOfFile: setupPropertylist())
        for element in dict! {
            print("test element title = \(element["title"])")
            print("test element tags = \(element["tags"])")
            print("test element uRL = \(element["uRL"])")
            XCTAssertEqual(element["title"], testTitle)
            XCTAssertEqual(element["tags"], testTags)
            XCTAssertEqual(element["uRL"], testURL)
        }
        
    }
    
    /**
     Test adding multi Photos detail in property list
     */
    func testAddingPhotosToPropertyList() {
        let testTitle = "Fake Title"
        let testTags = ["Fake University", "New Brisbane"]
        let testURL = "http://www.fakeimage.png"
        let testTitle2 = "Fake2 Title"
        let testTags2 = ["Fake2 University", "Great work"]
        let testURL2 = "http://www.Fake2.jpg"
        let newPhoto = Photo(title: testTitle, tags: testTags, uRL: testURL)
        let newPhoto2 = Photo(title: testTitle2, tags: testTags2, uRL: testURL2)
        let pl = propertyListRepresentation(newPhoto)
        let pl2 = propertyListRepresentation(newPhoto2)
        
        let arrayNS : NSMutableArray = []
        arrayNS.addObject(pl)
        arrayNS.writeToFile(setupPropertylist(), atomically: true)              //write file
        var dict = NSMutableArray(contentsOfFile: setupPropertylist())          //load file
        XCTAssertEqual(dict!.count, 1)
        arrayNS.addObject(pl2)
        arrayNS.writeToFile(setupPropertylist(), atomically: true)              //write file
        dict = NSMutableArray(contentsOfFile: setupPropertylist())              //load file
        XCTAssertEqual(dict!.count, 2)
    }
    
    /**
     Test insert Photo details in property list
     */
    func testloadingPhotofromPropertyList() {
        let testTitle = "Fake Title"
        let testTags = ["Fake University", "New Brisbane"]
        let testURL = "http://www.fakeimage.png"
        let testTitle2 = "Fake2 Title"
        let testTags2 = ["Fake2 University", "Great work"]
        let testURL2 = "http://www.Fake2.jpg"
        let newPhoto = Photo(title: testTitle, tags: testTags, uRL: testURL)
        let newPhoto2 = Photo(title: testTitle2, tags: testTags2, uRL: testURL2)
        let pl = propertyListRepresentation(newPhoto)
        let pl2 = propertyListRepresentation(newPhoto2)
        
        let arrayNS : NSMutableArray = []
        arrayNS.addObject(pl)
        arrayNS.writeToFile(setupPropertylist(), atomically: true)              //write file
        var dict = NSMutableArray(contentsOfFile: setupPropertylist())          //load file
        XCTAssertEqual(dict!.count, 1)                                          //Confirm property list size
        for element in dict! {
            print("test element title = \(element["title"])")
            print("test element tags = \(element["tags"])")
            print("test element uRL = \(element["uRL"])")
            XCTAssertEqual(element["title"], testTitle)
            XCTAssertEqual(element["tags"], testTags)
            XCTAssertEqual(element["uRL"], testURL)
        }
        arrayNS.addObject(pl2)
        arrayNS.writeToFile(setupPropertylist(), atomically: true)              //write file
        dict = NSMutableArray(contentsOfFile: setupPropertylist())              //load file
        XCTAssertEqual(dict!.count, 2)                                          //Confirm propety list size
        //      print(dict?.count)
        //      print(dict![1])
        
        let element0 = dict!.objectAtIndex(0)
        XCTAssertEqual(element0["title"], testTitle)
        XCTAssertEqual(element0["tags"], testTags)
        XCTAssertEqual(element0["uRL"], testURL)
        let element1 = dict!.objectAtIndex(1)
        //      print("test element title = \(element1["title"])")
        //      print("test element tags = \(element1["tags"])")
        //      print("test element uRL = \(element1["uRL"])")
        XCTAssertEqual(element1["title"], testTitle2)
        XCTAssertEqual(element1["tags"], testTags2)
        XCTAssertEqual(element1["uRL"], testURL2)
        
        
    }
    
    /** Test delete Photo details in propety List
     
     */
    func testDeletePhotoInPropertyList() {
        let testTitle = "I still survive"
        let testTags = ["Hee", "hee"]
        let testURL = "firstWeb.png"
        let testTitle2 = "I will die first"
        let testTags2 = ["Oh", "my god"]
        let testURL2 = "diefirst.jpg"
        let testTitle3 = "Leave me alone"
        let testTags3 = ["Keep", "Quiet"]
        let testURL3 = "You're not alone.jpg"
        let newPhoto = Photo(title: testTitle, tags: testTags, uRL: testURL)
        let newPhoto2 = Photo(title: testTitle2, tags: testTags2, uRL: testURL2)
        let newPhoto3 = Photo(title: testTitle3, tags: testTags3, uRL: testURL3)
        let pl = propertyListRepresentation(newPhoto)
        let pl2 = propertyListRepresentation(newPhoto2)
        let pl3 = propertyListRepresentation(newPhoto3)
        
        let arrayNS : NSMutableArray = []
        arrayNS.addObject(pl)
        arrayNS.addObject(pl2)
        arrayNS.addObject(pl3)
        arrayNS.writeToFile(setupPropertylist(), atomically: true)              //write file
        let dict = NSMutableArray(contentsOfFile: setupPropertylist())          //load file
        XCTAssertEqual(dict!.count, 3)
        dict!.removeObjectAtIndex(1)    //remove the second object
        
        XCTAssertEqual(dict!.count, 2)  //check property list size
        let element0 = dict!.objectAtIndex(0)   // should display the first object
        XCTAssertEqual(element0["title"], testTitle)
        XCTAssertEqual(element0["tags"], testTags)
        XCTAssertEqual(element0["uRL"], testURL)
        let element1 = dict!.objectAtIndex(1)   // the third test object changed to second position
        XCTAssertEqual(element1["title"], testTitle3)
        XCTAssertEqual(element1["tags"], testTags3)
        XCTAssertEqual(element1["uRL"], testURL3)
        
        dict!.removeLastObject()
        XCTAssertEqual(dict!.count, 1)
        XCTAssertEqual(element0["title"], testTitle)
        XCTAssertEqual(element0["tags"], testTags)
        XCTAssertEqual(element0["uRL"], testURL)
    }
    
    //  MARK: - Tests - Photo class
    
    ///
    /// Test the title name, tags and uRL in normal correct input scenarios
    ///
    func testNormalInput() {
        let testTitle = "Griffith logo"
        let testTags = ["Griffith University, Company log, Red Flag"]
        let testURL = "http://www.studyinaus.com/wp-content/uploads/2014/02/logo2.gif"
        let testMyPhoto = Photo(title: "Griffith logo", tags:["Griffith University, Company log, Red Flag"], uRL: "http://www.studyinaus.com/wp-content/uploads/2014/02/logo2.gif")
        XCTAssertEqual(testMyPhoto.title, testTitle)
        XCTAssertEqual(testMyPhoto.tags, testTags)
        XCTAssertEqual(testMyPhoto.uRL, testURL)
    }
    
    ///
    /// Test a class of Photo's properties if either tags or uRL is entere whether return tht correct value
    ///
    func testEmptyStringInput() {
        
        //Only title argument is entered
        let testTitle = "Griffith"
        var testMyPhoto = Photo(title: testTitle, tags: [], uRL: "")
        XCTAssertEqual(testMyPhoto.title, testTitle)
        XCTAssertEqual(testMyPhoto.tags, [])
        XCTAssertEqual(testMyPhoto.uRL, "")
        
        //Only tags argument is entered
        let testTags = ["Griffith University, Company log, Red Flag"]
        testMyPhoto = Photo(title: "", tags: testTags, uRL: "")
        XCTAssertEqual(testMyPhoto.title, "")
        XCTAssertEqual(testMyPhoto.tags, testTags)
        XCTAssertEqual(testMyPhoto.uRL, "")
        
        //Only URL argument is entered
        let testURL = "http://yahoo.com.au"
        testMyPhoto = Photo(title: "", tags: [], uRL: testURL)
        XCTAssertEqual(testMyPhoto.title, "")
        XCTAssertEqual(testMyPhoto.tags, [])
        XCTAssertEqual(testMyPhoto.uRL, testURL)
        
        
        //all empty strings
        testMyPhoto = Photo(title: "", tags: [], uRL: "")
        XCTAssertEqual(testMyPhoto.title, "")
        XCTAssertEqual(testMyPhoto.tags, [])
        XCTAssertEqual(testMyPhoto.uRL, "")
    }

}
