//
//  ViewController.swift
//  MyPhotos
//
//  Created by s2193948 on 8/04/2016.
//  Copyright © 2016 s2193948. All rights reserved.
//  Purpose: This class is the collection view that list out all the images, and can modify exisiting photos' details or adding a new image

import UIKit

class MasterViewController: UICollectionViewController, DetailViewControllerDelegate {
    
    // MARK: Properties
    
    var masterEntries = PhotoList().entries //the list to store the images
    var currentImageIndex : Int? = nil    //replaced by below photo object
    var currentPhoto: Photo? = nil
    var validated: Bool = false
    
    // MARK: Main UI Functions
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    
        //load default image (3 samples)
        masterEntries.append(Photo(title: "Griffith", tags: ["GU", "Great"], uRL: "http://www.acsfoundation.com.au/bdi/assets/img/logos/Griffith3.png"))
        masterEntries.append(Photo(title: "UQ", tags: ["GU", "Oh"], uRL: "http://www.uq.edu.au/international/images/banners/UQlogoC-colour-M.jpg"))
        masterEntries.append(Photo(title: "QUT", tags: ["QUT", "Yeah"], uRL: "http://acems.org.au/acems_wp/wp-content/uploads/2015/09/QUT_Logo_2Lines_CMYK.jpg"))
        
       // For reference only as below
       // let linkURL = NSURL(string: masterEntries[0].uRL!)
       // let data = NSData(contentsOfURL: linkURL!)
       // let image = UIImage(data: data!)
    
    /*  for foto in photolist {
        loadPhotoInBackground(photo: foto) // load the function which download an image in background (Multithread)
        }
    */
    
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        self.collectionView!.reloadData()       //reload images
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: PrepareForSegue
    /**
        Show selected image by segue or adding a new photo details
    */
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "ShowImage" {
            //print("Segue = ShowImage")    //tester//
            let dvc = segue.destinationViewController as! DetailViewController
            //print(dvc)    //tester//
            let indexPaths = self.collectionView!.indexPathsForSelectedItems()  //mutli selected
            //print(indexPaths) //tester//
            let indexPath = indexPaths![0] as NSIndexPath                       //single select
            //tester print("index Path = \(indexPath.row)")  //tester//
            
            
            if let tempLink = masterEntries[indexPath.row].uRL{ //Double confirm the url isn't nil
                let link = NSURL(string: tempLink)
                if let data = NSData(contentsOfURL: link!) {
                    if let image = UIImage(data: data) {
                        dvc.currentImage = image
                    }
                }
                currentPhoto = masterEntries[indexPath.row] // refer the existing object
                currentImageIndex = indexPath.row //save current object index
                dvc.photoDVC = masterEntries[indexPath.row] // original is currentPhoto
                dvc.dvcDelegate = self
            }else{
               print("nothing in tempLink")
            }

        }else if segue.identifier == "AddImage" {
            print("Segue = AddImage")
            let dvc = segue.destinationViewController as! DetailViewController
            dvc.dvcDelegate = self  //very important
        }
    }
    
    // MARK: Functions
    
    /**
        Save image to the array list
        - Parameter photo: the photo object from DVC
    */
    
    func savePhotoDetails(photo: Photo, exisitngPhoto: Bool){
        //  1) validate the Photo object link(String) is valid (nil or empty string)
        //  2) decide the Argument is a new or exisiting photo object
        //  3) save the details or not save
        
        if validatePhoto(photo) == true {   // confirm is link is validated
            print("validated Photo")
            print("photolink is \(photo.uRL!)")
            if exisitngPhoto == true {    // is a existing object
                masterEntries[currentImageIndex!] = photo
                print("Save exsting Photo object")
            }else{          //is a new object
                masterEntries.append(photo)
                print("Save a new Photo object")
            }
        }
        print("masterEntries now is = \(masterEntries.count)")
        currentImageIndex = nil
        currentPhoto = nil
    }
    
    /**
        Validate the photo that at least has a link
        - Parameter photo: the Photo object passed from DetailViewController
        - Returns: true if confirmed URL link is not a empty string or nil
    */
    func validatePhoto (photo: Photo) -> Bool{
        print("validating photo \(photo.uRL!)")
        if photo.uRL != nil || photo.uRL != "" {
            print("validate photo.uRL is not nil")
            return true
        }else{
            return false
        }
    }
    
    // MARK: CollectionView
    // First, set the number of sections
    /**
        Counting the number of items in Photolist to show
    */
    override func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return masterEntries.count
    }
    
    // Second, set the cell
    /**
        Setup the cells by the datasource of Photo modal
    */
    override func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) ->UICollectionViewCell {
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier("photoCell", forIndexPath: indexPath) as! CollectionViewCell
        if let tempLink = masterEntries[indexPath.row].uRL {
            let link = NSURL(string: tempLink)
            if let data = NSData(contentsOfURL: link!) {
                if let currentPhoto = UIImage(data: data){
                cell.cellImage.image = currentPhoto     //image is the property of UIImageView
                }
            }
        }
        return cell
    }
    
    
    /*
        Queue the image download in background, then reload the photolist
        - Parameter Photo: the image that need to download
    */
    
    
    
  /*  func loadPhotoInBackground (photo: Photo) {
        
        let queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0)
        
        let backgroundDownload = {      //Closure
            
  //         if let data = NSData(contentsOfURL: NSURL(string: photo.urL)!) {
            if let data = NSData(contentsOfURL: NSURL(string: photo.uRL!)!) {
                let mainQueue = dispatch_get_main_queue()
                dispatch_async(mainQueue, {
                    //photo.imageData = data  // need a method change the NSData back to link // for store image in a Photo list
                    
                    self.collectionView!.reloadData()       //reload image after downloaded
               })
            }else{
                print("Could not download image '\(photo.urlStr)'")
            }
        }
        
        dispatch_async(queue, backgroundDownload)
    }
    
   */
    
}   // class end

