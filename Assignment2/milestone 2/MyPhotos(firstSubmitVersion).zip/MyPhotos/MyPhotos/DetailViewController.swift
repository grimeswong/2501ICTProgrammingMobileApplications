//
//  DetailViewController.swift
//  MyPhotos
//
//  Created by s2193948 on 8/04/2016.
//  Copyright © 2016 s2193948. All rights reserved.
//  Purpose: This detailview controller can show the image with title, tags, and save it by the back button. Also can modify the current photo's details

import UIKit

protocol DetailViewControllerDelegate {
    func savePhotoDetails(photoDVC: Photo)  //  1) set Delegate (first step)
}

class DetailViewController: UIViewController, UITextFieldDelegate { //must subclass UITextFieldDelegate for dismissing the keyboard after typed in textfields
    
    
    // MARK: Properties
    @IBOutlet weak var displayImage: UIImageView!
    
    @IBOutlet weak var titleTextField: UITextField!
    @IBOutlet weak var tagsTextField: UITextField!
    @IBOutlet weak var uRLTextField: UITextField!
    
    var photoDVC: Photo? = nil
    var currentImageData: NSData?
    var currentImage: UIImage?
    
    var dvcDelegate : DetailViewControllerDelegate? = nil   //  2) set Delegate (second step)
    
    // MARK: Main UI Functions
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /**
        Execute the data prior to show the detail view
    */
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        if photoDVC != nil {    // decide whether is a new or exisiting object
            showDetails()       // show existing object details
        }
    }
    
    /**
        Pass the Photo object to MVC before disappear
    */
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(true)
        if dvcDelegate != nil {
            // method to execute
            saveDetails()   //save the title, tags and URL to the photoDVC object
            if photoDVC != nil{
                print("photoDVC is not nil")
                dvcDelegate!.savePhotoDetails(self.photoDVC!)   // confirm the photoDVC has a object.
            }
            self.photoDVC = nil
            self.currentImage = nil
            
        }
    }
    
    //For reference only as below
    //let link = "http://www.acsfoundation.com.au/bdi/assets/img/logos/Griffith3.png"
    //let linkURL = NSURL(string: link)
    //let data = NSData(contentsOfURL: linkURL!)
    
    // MARK: Function of show details
    /**
        Show the details refer from the photoDVC object passed from MasterView
    */
    func showDetails(){
        if let title = photoDVC!.title {
            titleTextField.text! = title
        }
        if let tags = photoDVC!.tags {
            var tempTags = ""
            for temp in tags{
                tempTags += temp + ","
            }
            tagsTextField.text! = tempTags
        }
        if let uRL = photoDVC!.uRL {
            uRLTextField.text! = uRL
        }
        // show the image if it's not nil
        if let validImage = currentImage {
            self.displayImage.image = validImage
        }

    }
    
    /**
        Function to save the details includes title, tags and URL
    */
    func saveDetails(){
        var tempTitle : String? = nil
        var tempTags : [String]? = nil
        var tempURL : String? = nil
        if let title = titleTextField.text{
            tempTitle = title
            print("Save title")
        }
        if let tags = tagsTextField.text{
            //photoDVC!.tags =
            var array: [String]=[]
            
            for temp in tags.componentsSeparatedByString(",") {
                array.append(temp)
            }
            tempTags = array
            print("Save tags")
        }
        
        if let url = uRLTextField.text{
            tempURL = url
            print("Save URL")
        }
        
        print("dvc details are \(tempTitle) + \(tempTags) + \(tempURL)")
        if tempURL != "" {
            photoDVC = Photo(title: tempTitle, tags: tempTags, uRL: tempURL)
            print(photoDVC!.uRL)
        }
    }
     
    
    // MARK: Function of dismiss the keyboard & downloading image in background
    /**
        Dismiss the keyboard after the user press the return key
        Download an image in background after the user press the return button in URL textfield
        - Parameter textField: the current input textfield
        - Returns: true
    */
    func textFieldShouldReturn(textField: UITextField) -> Bool { // called when 'return' key pressed. return NO to ignore.
        textField.resignFirstResponder()    // disappear keyboard (This textField argument can be include all the text field in the same view controller
        
        if let urlName = uRLTextField.text,
            let url = NSURL(string: urlName){
                let queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0)
                
                dispatch_async(queue, {
                    if let data = NSData(contentsOfURL: url), // download some binary data, allow specific attempt to download the data
                        let image = UIImage(data: data) {        // get the image from data
                            //sleep(3)                             // sleep 3seonds for simulating
                            self.displayImage.image = image
                    }else{
                        print("Could not download image \(urlName)")
                    }
                })
        }

        
        return true
    }
}
