//
//  PhotoList.swift
//  MyPhotos
//
//  Created by Grimes Wong on 18/04/2016.
//  Copyright © 2016 s2193948. All rights reserved.
//
//  Purpose: This class is for storing a photo into an array

import Foundation

class PhotoList {
    
    
    //  MARK: Property
    
    /// A PhotoList to store photos
    var entries: [Photo] = [] // intialise a empty Photo array
    
}