//
//  DetailViewController.swift
//  MyPhotos
//
//  Created by s2193948 on 8/04/2016.
//  Copyright © 2016 s2193948. All rights reserved.
//  Purpose: This detailview controller can show the image with title, tags, and save it by the back button. Also can modify the current photo's details

import UIKit

protocol DetailViewControllerDelegate {
    func savePhotoDetails(photoDVC: Photo, exisitngPhoto: Bool)  //  1) set Delegate (first step)
}

class DetailViewController: UIViewController, UITextFieldDelegate { //must subclass UITextFieldDelegate for dismissing the keyboard after typed in textfields
    
    
    // MARK: Properties
    @IBOutlet weak var displayImage: UIImageView!
    
    @IBOutlet weak var titleTextField: UITextField!
    @IBOutlet weak var tagsTextField: UITextField!
    @IBOutlet weak var uRLTextField: UITextField!
    
    var existingPhoto: Bool=false
    var photoDVC: Photo?
    var currentImage: UIImage?
    var dvcDelegate : DetailViewControllerDelegate? = nil   //  2) set Delegate (second step)
    
    // MARK: Main UI Functions
    
  /*  override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   */
    
    /**
        Execute the data prior to show the detail view
    */
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        let nav = navigationController?.navigationBar   // change the navigation bar title to green colour
        nav?.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.greenColor()]
        
        if photoDVC != nil {    // decide whether is a new or exisiting object
            existingPhoto = true    //set true for later saving method
            showDetails()       // show existing object details
        }
    }
    
    /**
        Pass the Photo object to MVC before disappear
    */
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(true)
        if dvcDelegate != nil {
            // method to execute
            saveDetails()   //save the title, tags and URL to the photoDVC object
            if photoDVC != nil{
                dvcDelegate!.savePhotoDetails(self.photoDVC!, exisitngPhoto: self.existingPhoto)   // confirm the photoDVC has a object.
            }
        }
    }
    
    //For reference only as below
    //let link = "http://www.acsfoundation.com.au/bdi/assets/img/logos/Griffith3.png"
    //let linkURL = NSURL(string: link)
    //let data = NSData(contentsOfURL: linkURL!)
    
    // MARK: Function of show details
    /**
        Show the photo details by the photoDVC object passed from MasterView
    */
    func showDetails(){
        //print("existigPhoto = \(existingPhoto)")
        titleTextField.text = photoDVC!.title   //implicitly unwrap optional
        tagsTextField.text = photoDVC!.tags!.joinWithSeparator(",")
        uRLTextField.text! = photoDVC!.uRL!
        self.displayImage.image = currentImage
      }
        
    
    /**
        Function to save the details includes title, tags and URL
    */
    func saveDetails(){
        let tempTitle : String
        let tempTags : [String]
        let tempURL : String
        
        tempTitle = titleTextField.text!
        print("Save title")
        
        let tags = tagsTextField.text!
        tempTags = tags.componentsSeparatedByString(",")
        print("Save tags")
        
        tempURL = uRLTextField.text!
        print("Save URL")
        
        print("dvc details are \(tempTitle) + \(tempTags) + \(tempURL)")
        if tempURL != ""{
            photoDVC = Photo(title: tempTitle, tags: tempTags, uRL: tempURL)
        }else{
            photoDVC = nil
        }
    }
     
    
    // MARK: Function of dismiss the keyboard & preview image which
    /**
        Dismiss the keyboard after the user press the return key
        Preview an image by downloading in background after the user press the return button with filled correct URL in URL textfield
        - Parameter textField: the current input textfield
        - Returns: true
    */
    func textFieldShouldReturn(textField: UITextField) -> Bool { // called when 'return' key pressed. return NO to ignore.
        
        if let urlName = uRLTextField.text,
            let url = NSURL(string: urlName){
                let queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0)
                
                dispatch_async(queue, {
                    if let data = NSData(contentsOfURL: url), // download some binary data, allow specific attempt to download the data
                        let image = UIImage(data: data) {        // get the image from data
                            
                            self.displayImage.image = image
                    }else{
                        print("Could not download image \(urlName)")
                    }
                })
        }
        textField.resignFirstResponder()    // disappear keyboard (This textField argument can be include all the text field in the same view controller

        return true
    }
}
