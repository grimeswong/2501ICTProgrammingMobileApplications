//
//  Photo.swift
//  MyPhotos
//
//  Created by Grimes Wong on 18/04/2016.
//  Copyright © 2016 s2193948. All rights reserved.
//
//  Purpose: This class is for storing a photo with the title, tags and the URL link


import Foundation

class Photo {
    
    //  MARK: Properties
    var title: String! = nil        //implicitly unwrap optional title that the photo should have at least one of title
    var tags: [String]? = nil
    var uRL: String? = nil
    
    
    //  MARK: designated initialiser
    /**
        Deisignated initialiser with three parameters
        - parameters:
            - title: Title of photo
            - tags: Tags of photo
            - uRL: URL link of photo
    */
    init(title: String? = nil, tags: [String]? = nil, uRL: String? = nil){
        self.title = title
        self.tags = tags
        self.uRL = uRL
    }
}
