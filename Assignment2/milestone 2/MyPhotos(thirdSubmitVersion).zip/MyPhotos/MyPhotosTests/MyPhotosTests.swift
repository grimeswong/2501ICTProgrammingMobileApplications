//
//  MyPhotosTests.swift
//  MyPhotosTests
//
//  Created by s2193948 on 8/04/2016.
//  Copyright © 2016 s2193948. All rights reserved.
//

import XCTest
@testable import MyPhotos

class MyPhotosTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measureBlock {
            // Put the code you want to measure the time of here.
        }
    }
    
    
    
    //  MARK: - Tests - Photo class
    
    ///
    /// Test the title name, tags and uRL in normal correct input scenarios
    ///
    func testNormalInput() {
        let testTitle = "Griffith logo"
        let testTags = ["Griffith University, Company log, Red Flag"]
        let testURL = "http://www.studyinaus.com/wp-content/uploads/2014/02/logo2.gif"
        let testMyPhoto = Photo(title: "Griffith logo", tags:["Griffith University, Company log, Red Flag"], uRL: "http://www.studyinaus.com/wp-content/uploads/2014/02/logo2.gif")
        XCTAssertEqual(testMyPhoto.title!, testTitle)
        XCTAssertEqual(testMyPhoto.tags!, testTags)
        XCTAssertEqual(testMyPhoto.uRL!, testURL)
    }
    
    ///
    /// Test a class of Photo's properties if either tags or uRL is entere whether return tht correct value
    ///
    func testNilInput() {
        
        //Only title argument is entered
        let testTitle = "Griffith"
        var testMyPhoto = Photo(title:"Griffith")
        XCTAssertEqual(testMyPhoto.title!, testTitle)   //unwrap optional of title to get value
        XCTAssertNil(testMyPhoto.tags)
        XCTAssertNil(testMyPhoto.uRL)
        
        //Only tags argument is entered
        let testTags = ["Griffith University, Company log, Red Flag"]
        testMyPhoto = Photo(tags: ["Griffith University, Company log, Red Flag"])
        XCTAssertNil(testMyPhoto.title)
        XCTAssertEqual(testMyPhoto.tags!, testTags)     //unwrap optionals of tags to get value
        XCTAssertNil(testMyPhoto.uRL)
        
        //Only URL argument is entered
        let testURL = "yahoo.com.au"
        testMyPhoto = Photo(uRL: "yahoo.com.au")
        XCTAssertNil(testMyPhoto.title)    //unwrap optional of uRL to get value
        XCTAssertNil(testMyPhoto.tags)
        XCTAssertEqual(testMyPhoto.uRL!, testURL)
        
    }
    
    ///
    /// Test all nil input
    ///
    func testAllNilInput(){
        
        //all argument is nil
        let testMyPhoto = Photo()
        XCTAssertNil(testMyPhoto.title)
        XCTAssertNil(testMyPhoto.tags)
        XCTAssertNil(testMyPhoto.uRL)
    }
    
    ///
    /// Test the title implicity unwrap the String
    ///
    func testTitleImplicityUnwrappedOptional(){
        
        var testMyPhoto = Photo()
        XCTAssertNil(testMyPhoto.title)
        testMyPhoto = Photo(title: "Testing")
        XCTAssertNotNil(testMyPhoto.title)  // don't need a "!" to unwrap a implicity option
        let testTitle = "Griffith"
        testMyPhoto = Photo(title: testTitle)
        XCTAssertEqual(testMyPhoto.title, testTitle)
    }
    
    ///
    /// Test the elements in tags array
    /// - Array
    func testTags() {
        let testTags = ["GU", "QUT", "UQ"]
        let testMyPhoto = Photo(title:"Griffith",tags:testTags, uRL:nil)
        
        for(var i=0;i<testTags.count;i++){
            testMyPhoto.tags![i] = testTags[i]
            XCTAssertEqual(testMyPhoto.tags![i], testTags[i])
        }
    }
    
    ///
    /// Test getter and setter of a assumeed Photo class
    ///
    func testGetterAndSetter() {
        let testTitle = ["Griffith", "QUT", "UQ", "QIBT"]
        let testTags = [["G","U"], ["Q","U","T"],["U","Q"],["Q","I","B","T"]]
        let testuRL = ["griffith.edu.au", "qut.edu.au", "uq.edu.au", "qibt.edu.au"]
        
        let testMyPhoto = Photo(title:nil, tags:nil, uRL:nil)
        
        for title in testTitle {
            testMyPhoto.title = title
            
            for tag in testTags {
                testMyPhoto.tags = tag
                
                for uRL in testuRL {
                    testMyPhoto.uRL = uRL
                    
                    XCTAssertEqual(testMyPhoto.title, title)    //don't need to unwrap optional to get value
                    XCTAssertEqual(testMyPhoto.tags!, tag)     //need to unwrap optional to get value
                    XCTAssertEqual(testMyPhoto.uRL!, uRL)   //need to unwrap optional to get value
                    
                }
            }
        }
    }
    
    // Tests end
}
