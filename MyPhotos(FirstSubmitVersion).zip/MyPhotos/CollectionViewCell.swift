//
//  CollectionViewCell.swift
//  MyPhotos
//
//  Created by Grimes Wong on 18/04/2016.
//  Copyright © 2016 s2193948. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var cellImage: UIImageView!
}
